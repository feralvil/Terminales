<?php
// ------------ Obtención del usuario Joomla! --------------------------------------- //
        // Le decimos que estamos en Joomla
        define( '_JEXEC', 1 );

	// Definimos la constante de directorio actual y el separador de directorios (windows server: \ y linux server: /)
	define( 'DS', DIRECTORY_SEPARATOR );
	define('JPATH_BASE', dirname(__FILE__).DS.'..' );

	// Cargamos los ficheros de framework de Joomla 1.5, y las definiciones de constantes (IMPORTANTE AMBAS LÍNEAS)
	require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

	// Iniciamos nuestra aplicación (site: frontend)
	$mainframe =& JFactory::getApplication('site');

	// Obtenemos los parámetros de Joomla
	$user =& JFactory::getUser();
	$usu = $user->username;
// ------------------------------------------------------------------------------------- //

// ------------ Conexión a BBDD de Terminales ----------------------------------------- //
        include("conexion.php");
        $base_datos=$dbbdatos;
        $link=mysql_connect($dbserv,$dbusu,$dbpaso);
        if(!link){
            echo "<b>ERROR MySQL:</b>".mysql_error();
        }
// ------------------------------------------------------------------------------------- //

import_request_variables("gp","");

/* Determinamos si es usuario OFICINA COMDES para ver la gestión de flotas */
$sql_oficina="SELECT ID FROM flotas WHERE LOGIN='$usu'";
$res_oficina=mysql_db_query($base_datos,$sql_oficina);
$row_oficina=mysql_fetch_array($res_oficina);
$flota_usu=$row_oficina["ID"];
/*
 *  $permiso = variable de permisos de flota:
 *      0: Sin permiso
 *      1: Permiso de consulta
 *      2: Permiso de modificación
 */
$permiso=0;
if($flota_usu==100){
    $permiso = 2;
}
else {
    $sql_permiso = "SELECT * FROM usuarios_flotas WHERE NOMBRE='$usu'";
    $res_permiso = mysql_db_query($base_datos,$sql_permiso) or die(mysql_error());
    $npermiso = mysql_num_rows($res_permiso);
    if ($npermiso == 0){
        $permiso = 0;
    }
    elseif ($npermiso == 1) {
        $row_permiso = mysql_fetch_array($res_permiso);
        if ($id==$row_permiso["FLOTA_ID"]){
            $permiso = 1;
        }
    }
    else {
        for ($i=0; $i < $npermiso; $i++){
            $row_permiso = mysql_fetch_array($res_permiso);
            if ($id==$row_permiso["ID_FLOTA"]){
                $permiso++;
            }
        }
    }
}
?>
<html>
<head>
<title>Acceso a Flotas COMDES</title>
<link rel="StyleSheet" type="text/css" href="estilo.css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>
<?php
	if($permiso!=0){
		//datos de la tabla Flotas
		$sql_flota="SELECT * FROM flotas WHERE ID='$id'";
		$res_flota=mysql_db_query($base_datos,$sql_flota) or die ("Error en la consulta de Flota: ".mysql_error());
		$nflota=mysql_num_rows($res_flota);
		if($nflota==0){
			echo "<p class='error'>No hay resultados en la consulta de la Flota</p>\n";
		}
		else{
			$row_flota=mysql_fetch_array($res_flota);
                        $usuario = $row_flota["LOGIN"];
		}
?>
<h1>Permisos de la Flota <?php echo utf8_encode($row_flota["FLOTA"]);?></h1>
<h2>Datos Administrativos de la Flota</h2>
	<table>
		<TR>
			<TH class="t40p">Nombre</TH>
			<TH class="t5c">Acrónimo</TH>
			<TH class="t5c">Usuario</TH>
			<TH class="t10c">Activa</TH>
			<TH class="t10c">Encriptación</TH>
		</TR>
		<TR>
			<TD><?php echo utf8_encode($row_flota["FLOTA"]);?></TD>
			<TD><?php echo $row_flota["ACRONIMO"];?></TD>
			<TD><?php echo $row_flota["LOGIN"];?></TD>
			<TD><?php echo $row_flota["ACTIVO"];?></TD>
                        <TD><?php echo $row_flota["ENCRIPTACION"];?></TD>
		</TR>
	</table>
<form action="permisos_flota.php?id=<?php echo $id;?>" name="formulario" method="POST">
<h2>Flotas a las que tiene acceso</h2>
	<?php
                $sql_flotas = "SELECT ID, ACRONIMO, FLOTA, ENCRIPTACION FROM flotas, usuarios_flotas WHERE ";
                $sql_flotas = $sql_flotas."usuarios_flotas.NOMBRE='$usuario' AND flotas.ID = usuarios_flotas.ID_FLOTA";
                if ($tam_pagina==""){
                    $tam_pagina=10;
                }
		if(!$pagina){
			$inicio=0;
			$pagina=1;
		}
		else{
			$inicio=($pagina-1)*$tam_pagina;
		}
		if (($flota!='')&&($flota!="00")){
			$sql_flotas=$sql_flotas." WHERE (flotas.ID='$flota')";
		}
		$sql_no_limit=$sql_flotas." ORDER BY flotas.FLOTA ASC";
		$sql_limit=$sql_no_limit." LIMIT ".$inicio.",".$tam_pagina.";";
		$res=mysql_db_query($base_datos,$sql_no_limit) or die(mysql_error());
		$nfilas=mysql_num_rows($res);
		$total_pag=ceil($nfilas/$tam_pagina);
	?>
<h4>Resultado de la búsqueda</h4>
<table>
	<tr class="borde">
		<td class="borde">Nº total de registros: <b><?php echo $nfilas;?></b>.</td>
		<td class="borde">
			Mostrar:
			<select name='tam_pagina' onChange='document.formulario.submit();'>
			<?php
				echo "<option value='10' ";
				if (($tam_pagina=="10") || ($tam_pagina=="")) {
					echo 'selected';
				}
				echo ">10</option>\n";
				echo "<option value='20' ";
				if ($tam_pagina=="20") {
					echo 'selected';
				}
				echo ">20</option>\n";
				echo "<option value='30' ";
				if ($tam_pagina=="30") {
					echo 'selected';
				}
				echo ">30</option>\n";
				echo "<option value='$nfilas' ";
				if ($tam_pagina=="$nfilas") {
					echo 'selected';
				}
				echo ">Todos</option>\n";
			?>
			</select> registros por página
		</td>
		<td class="borde">
		<?php
			if ($total_pag>1){
				echo "Página: \n";
				echo "<select name='pagina' onChange='document.formulario.submit();'>\n";
				for($k=1;$k<=$total_pag;$k++){
					echo "<option value='$k' ";
					if ($pagina==$k) {
						echo 'selected';
					}
					echo ">$k</option>\n";
				}
				echo "</select>\n";
				echo " de $total_pag\n";
			}
		?>
		</td>
	</tr>
</table>
</form>
<table>
<?php
if ($nfilas==0){
	echo "<tr><td class='borde'>No hay registros</tr></td>";
}
else {
	if($res2=mysql_db_query($base_datos,$sql_limit)){
		$nfilas2=mysql_num_rows($res2);
		$ncampos=mysql_num_fields($res2);
		//*TABLA CON RESULTADOS*//
		echo "<tr>\n";
		//* CABECERA  *//
		$campos=array("Detalle","Flota","Acrónimo","Encriptación","Total Terminales","T. Portátiles","T. Móviles","T. Base");
		for($i=0;$i<count($campos);$i++){
			echo "<th>";
			echo $campos[$i];
			echo "</th>\n";
		}
		echo "</tr>\n";
		$fila=mysql_fetch_array($res2);
		for($i=0;$i<$nfilas2;$i++){
			echo "<tr";
			if (($i % 2) == 1){
				echo " class='filapar'";
			}
			echo ">\n";
			for($j=0;$j<$ncampos;$j++){
				$campo_num=mysql_field_name($res2,$j);
				if($campo_num=="ID"){   //enlace a detalle
					echo "<td class='centro'>";
	                		echo "<a href='detalle_flota.php?id=$fila[0]'>";
					echo "<img src='imagenes/consulta.png'></a>";
				}
				else{
					echo "<td>".utf8_encode($fila[$campo_num]);
				}
				echo "</td>\n";
			} //segundo for
			//datos de la tabla Terminales
			// Tipos de termninales
			$tipos = array("F","M%", "P%");
			$nterm = array (0,0,0);
			$sql_term = "SELECT * FROM terminales WHERE FLOTA='$fila[0]'";
			$res_term = mysql_db_query($base_datos,$sql_term) or die ("Error en la consulta de Terminales".mysql_error());
			$tot_term = mysql_num_rows($res_term);
			echo "<td class='centro'>$tot_term</td>\n";
			for($j=0; $j< count($tipos);$j++){
				$sql_term = "SELECT * FROM terminales WHERE FLOTA='$fila[0]' AND TIPO LIKE '".$tipos[$j]."'";
				$res_term = mysql_db_query($base_datos,$sql_term) or die ("Error en la consulta de ".$cabecera[$j].": ".mysql_error());
				$nterm[$j] = mysql_num_rows($res_term);
				echo "<td class='centro'>$nterm[$j]</td>\n";
			}
			echo "</tr>\n";
			$fila=mysql_fetch_array($res2);
		} //primer for
		
	}
	else {
		echo "<b>ERROR:</b> ".mysql_error(); // si hay error en select_limit
	}
}
?>
</table>
	<table>
		<tr>
<?php
	if ($permiso==2){
?>

			<TD class="borde">
				<a href='agregar_flota.php?id=<?php echo $id?>'><img src='imagenes/activa.png' alt='Añadir'></a><br>Añadir acceso a Flota
			</TD>
<?php
            if ($nfilas > 1){
?>
			<TD class="borde">
                                <a href='eliminar_flota.php?id=<?php echo $id?>'><img src='imagenes/desactiva.png' alt='Eliminar'></a><br>Eliminar acceso a Flota
			</TD>
<?php
            }
        }
?>
			<TD class="borde">
				<a href='detalle_flota.php?id=<?php echo $id?>'><img src='imagenes/atras.png' alt='Listado'></a><br>Volver a Detalle
			</TD>
		</tr>
	</table>
<?php
	} // Si el usuario no es el de la Oficina
	else {
?>
	<h1>Acceso denegado</h1>
        <p class='error'>No le está permitido el acceso a los datos del conjunto de flotas. Usted sólo puede acceder a los datos de su flota: <a href="detalle_flota.php"><img src="imagenes/ir.png" alt="Ir"></a></p>
<?php
	}
?>
</body>
</html>
