<?php
// ------------ Obtención del usuario Joomla! --------------------------------------- //
        // Le decimos que estamos en Joomla
        define( '_JEXEC', 1 );

	// Definimos la constante de directorio actual y el separador de directorios (windows server: \ y linux server: /)
	define( 'DS', DIRECTORY_SEPARATOR );
	define('JPATH_BASE', dirname(__FILE__).DS.'..' );

	// Cargamos los ficheros de framework de Joomla 1.5, y las definiciones de constantes (IMPORTANTE AMBAS LÍNEAS)
	require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

	// Iniciamos nuestra aplicación (site: frontend)
	$mainframe =& JFactory::getApplication('site');

	// Obtenemos los parámetros de Joomla
	$user =& JFactory::getUser();
	$usu = $user->username;
// ------------------------------------------------------------------------------------- //

// ------------ Conexión a BBDD de Terminales ----------------------------------------- //
        include("conexion.php");
        $base_datos=$dbbdatos;
        $link=mysql_connect($dbserv,$dbusu,$dbpaso);
        if(!link){
            echo "<b>ERROR MySQL:</b>".mysql_error();
        }
// ------------------------------------------------------------------------------------- //

import_request_variables("gp","");

/* Determinamos si es usuario OFICINA COMDES para ver la gestión de flotas */
$sql_oficina="SELECT ID FROM flotas WHERE LOGIN='$usu'";
$res_oficina=mysql_db_query($base_datos,$sql_oficina);
$row_oficina=mysql_fetch_array($res_oficina);
$flota_usu=$row_oficina["ID"];
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Detalle del Terminal COMDES</title>
 <link rel="StyleSheet" type="text/css" href="estilo.css">
</head>
<?php
	//datos de la tabla terminales
	$sql_terminal="SELECT * FROM terminales WHERE ID='$id'";
	$res_terminal=mysql_db_query($base_datos,$sql_terminal) or die ("Error en la consulta de terminal: ".mysql_error());
	$nterminal=mysql_num_rows($res_terminal);
	if($nterminal==0){
		echo "<p class='error'>No hay resultados en la consulta del Terminal</p>\n";
	}
	else{
		$row_terminal=mysql_fetch_array($res_terminal);
		$id_flota = $row_terminal["FLOTA"];
	}
	//datos de la tabla flotas
	$sql_flota="SELECT * FROM flotas WHERE ID='$id_flota'";
	$res_flota=mysql_db_query($base_datos,$sql_flota) or die ("Error en la consulta de Flota Usuaria: ".mysql_error());
	$nflota=mysql_num_rows($res_flota);
	if($nflota==0){
		echo "<p class='error'>No hay resultados en la consulta de la Flota</p>\n";
	}
	else{
		$row_flota=mysql_fetch_array($res_flota);
	}
	//datos de la tabla municipios
	$ine = $row_flota ["INE"];
	$sql_mun = "SELECT * FROM municipios WHERE INE='$ine'";
	$res_mun = mysql_db_query($base_datos,$sql_mun) or die ("Error en la consulta de Municipio".mysql_error());
	$nmun = mysql_num_rows($res_mun);
	if($nmun==0){
		echo "<p class='error'>No hay resultados en la consulta del Municipio</p>\n";
	}
	else{
		$row_mun = mysql_fetch_array($res_mun);
	}
        /*
         *  $permiso = variable de permisos de flota:
         *      0: Sin permiso
         *      1: Permiso de consulta
         *      2: Permiso de modificación
         */
        $permiso=0;
        if($flota_usu==100){
            $permiso = 2;
        }
        else {
            $sql_permiso = "SELECT * FROM usuarios_flotas WHERE NOMBRE='$usu' AND ID_FLOTA='$id_flota'";
            $res_permiso = mysql_db_query($base_datos,$sql_permiso) or die(mysql_error());
            $npermiso = mysql_num_rows($res_permiso);
            if ($npermiso > 0){
                $permiso = 1;
            }
        }

	############# Enlaces para la exportación #######
	$linkpdf = "pdfterminal.php?id=$id";
	$linkxls = "xlsterminal.php?id=$id";
	$linkrtf = "rtfterminal.php?id=$id";
?>
<body>
<?php
	if($permiso != 0){
?>
<h1>
	Terminal TEI: <?php echo $row_terminal["TEI"];?> / ISSI: <?php echo $row_terminal["ISSI"];?> &mdash;
			<a href="<?php echo $linkpdf;?>"><img src="imagenes/pdf.png" alt="PDF" title="PDF"></a> &mdash;
			<a href="<?php echo $linkxls;?>"><img src="imagenes/xls.png" alt="Excel" title="XLS (Excel)"></a> &mdash;
			<a href="<?php echo $linkrtf;?>"><img src="imagenes/rtf.png" alt="RTF (Word)" title="RTF (Word)"></a>
	</h1>
	
<h2>Datos Administrativos del Terminal</h2>
	<table>
		<TR>
			<TH class="t6c">Tipo de Equipo</TH>
			<TH class="t6c">Marca</TH>
			<TH class="t6c">Modelo</TH>
			<TH class="t6c">Proveedor</TH>
			<TH class="t6c">Acuerdo Marco</TH>
			<TH class="t6c">Alta en el DOTS</TH>
		</TR>
		<TR>
<?php
		$tipo = $row_terminal["TIPO"];
		switch ($tipo){
			case ("F"): {
				$tipo = "Fijo";
				break;
			}
			case ("M"): {
				$tipo = "Móvil";
				break;
			}
			case ("MB"): {
				$tipo = "Móvil Básico";
				break;
			}
			case ("MA"): {
				$tipo = "Móvil Avanzado";
				break;
			}
			case ("MG"): {
				$tipo = "Móvil Gateway";
				break;
			}
			case ("P"): {
				$tipo = "Portátil";
				break;
			}
			case ("PB"): {
				$tipo = "Portátil Básico";
				break;
			}
			case ("PA"): {
				$tipo = "Portátil Avanzado";
				break;
			}
			case ("PX"): {
				$tipo = "Portátil ATEX";
				break;
			}
		}
?>
			<TD class="centro"><?php echo $tipo;?></TD>
			<TD class="centro"><?php echo $row_terminal["MARCA"];?></TD>
			<TD class="centro"><?php echo $row_terminal["MODELO"];?></TD>
			<TD class="centro"><?php echo utf8_encode($row_terminal["PROVEEDOR"]);?></TD>
			<TD class="centro"><?php echo $row_terminal["AM"];?></TD>
			<TD class="centro"><?php echo $row_terminal["DOTS"];?></TD>
		</TR>
	</table>
<h2>Datos de la Flota</h2>
	<table>
		<TR>
			<TH class="t40p">Nombre</TH>
			<TH class="t10c">Acrónimo</TH>
			<TH class="t40p">Localización</TH>
			<TH class="t10c">Ir a Flota</TH>
		</TR>
		<TR>
			<TD><?php echo utf8_encode($row_flota["FLOTA"]);?></TD>
			<TD><?php echo $row_flota["ACRONIMO"];?></TD>
			<TD><?php echo  utf8_encode($row_flota["DOMICILIO"])." &mdash; ".$row_flota["CP"]." ".utf8_encode($row_mun["MUNICIPIO"]);?></TD>
			<TD class="centro"><a href="detalle_flota.php?id=<?php echo $row_flota["ID"];?>"><img src="imagenes/ir.png" alt="Ir"></a></TD>
		</TR>
	</table>
<h3>Contactos de la Flota Usuaria</h3>
<?php
	if (($row_flota["RESPONSABLE"]=="0")&&($row_flota["CONTACTO1"]=="0")&&($row_flota["CONTACTO2"]=="0")&&($row_flota["CONTACTO3"]=="0")){
?>
		<p class='error'>No hay Contactos para la flota</p>
<?php
	}
	else{
?>
	<table>
		<TR>
			<TD class="t10c">&nbsp;</TD>
			<TH class="t4c">Nombre</TH>
			<TH class="t4c">Cargo</TH>
			<TH class="t10c">Teléfono</TH>
			<TH class="t10c">Móvil</TH>
			<TH class="t5c">Correo Electrónico</TH>
		</TR>

<?php
		$par = 0;
		// Datos de contactos
		$id_contacto = $row_flota["RESPONSABLE"];
		$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
		$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
		$ncontacto=mysql_num_rows($res_contacto);
		if($ncontacto!=0){
			$row_contacto=mysql_fetch_array($res_contacto);
?>
		<TR>
			<TH>Responsable</TH>
			<TD><?php echo utf8_encode($row_contacto["NOMBRE"]);?></TD>
			<TD><?php echo utf8_encode($row_contacto["CARGO"]);?></TD>
			<TD><?php echo utf8_encode($row_contacto["TELEFONO"]);?></TD>
			<TD><?php echo utf8_encode($row_contacto["MOVIL"]);?></TD>
			<TD><?php echo utf8_encode($row_contacto["MAIL"]);?></TD>
		</TR>
	<?php
			$par++;
		
		}
		if ($row_flota["CONTACTO1"]!="0"){
			$id_contacto = $row_flota["CONTACTO1"];
			$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
			$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
			$ncontacto=mysql_num_rows($res_contacto);
			if($ncontacto==0){
				echo "<p class='error'>No hay resultados en la consulta del Contacto 1</p>\n";
			}
			else{
				$row_contacto=mysql_fetch_array($res_contacto);
			}
	?>
			<TR <?php if (($par % 2)==1) echo "class='filapar'";?>>
				<TH>Contacto 1</TH>
				<TD><?php echo utf8_encode($row_contacto["NOMBRE"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["CARGO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["TELEFONO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MOVIL"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MAIL"]);?></TD>
			</TR>
	<?php
			$par++;
		}
		if ($row_flota["CONTACTO2"]!="0"){
			$id_contacto = $row_flota["CONTACTO2"];
			$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
			$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
			$ncontacto=mysql_num_rows($res_contacto);
			if($ncontacto==0){
				echo "<p class='error'>No hay resultados en la consulta del Contacto 2</p>\n";
			}
			else{
				$row_contacto=mysql_fetch_array($res_contacto);
			}
	?>
			<TR <?php if (($par % 2)==1) echo "class='filapar'";?>>
				<TH>Contacto 2</TH>
				<TD><?php echo utf8_encode($row_contacto["NOMBRE"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["CARGO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["TELEFONO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MOVIL"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MAIL"]);?></TD>
			</TR>
	<?php
			$par++;
		}
		if ($row_flota["CONTACTO3"]!="0"){
			$id_contacto = $row_flota["CONTACTO3"];
			$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
			$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
			$ncontacto=mysql_num_rows($res_contacto);
			if($ncontacto==0){
				echo "<p class='error'>No hay resultados en la consulta del Contacto 3</p>\n";
			}
			else{
				$row_contacto=mysql_fetch_array($res_contacto);
			}
	?>
			<TR <?php if (($par % 2)==1) echo "class='filapar'";?>>
				<TH>Contacto 3</TH>
				<TD><?php echo utf8_encode($row_contacto["NOMBRE"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["CARGO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["TELEFONO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MOVIL"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MAIL"]);?></TD>
			</TR>
	<?php
		}
	?>
	</table>
<?php
	}
?>
<h2>Datos Técnicos del Terminal</h2>
	<table>
		<TR>
			<TH class="t4c">ISSI</TH>
			<TD><?php echo $row_terminal["ISSI"];?></TD>
			<TH class="t4c">TEI</TH>
			<TD><?php echo $row_terminal["TEI"];?></TD>
		</TR>
                <TR class="filapar">
			<TH class="t4c">Código Hardware</TH>
			<TD><?php echo $row_terminal["CODIGOHW"];?></TD>
			<TH class="t4c">Número de Serie</TH>
			<TD><?php echo $row_terminal["NSERIE"];?></TD>
		</TR>
		<TR>
			<TH class="t4c">ID</TH>
			<TD><?php echo $row_terminal["ID"];?></TD>
			<TH class="t4c">Mnemónico</TH>
			<TD><?php echo $row_terminal["MNEMONICO"];?></TD>
		</TR>
		<TR class="filapar">
			<TH class="t4c">Llamada Semi-Dúplex</TH>
			<TD><?php echo $row_terminal["SEMID"];?></TD>
			<TH class="t4c">Llamada Dúplex</TH>
			<TD><?php echo $row_terminal["DUPLEX"];?></TD>
		</TR>
	<?php
		switch ($row_terminal["ESTADO"]){
			case "A":{
				$estado = "Alta";
				$fecha_nom = "Fecha de Alta";
				$fecha_val = $row_terminal["FALTA"];
				break;
			}
			case "B":{
				$estado = "Baja";
				$fecha_nom = "Fecha de Baja";
				$fecha_val = $row_terminal["FBAJA"];
				break;
			}
			case "R":{
				// Se busca la incidencia
				$sql_incid = "SELECT * FROM incidencias WHERE TERMINAL = '$id' ORDER BY ID DESC";
				$res_incid = mysql_db_query($base_datos,$sql_incid) or die ("Error en la consulta de Incidencia: ".mysql_error());
				$nincid=mysql_num_rows($res_incid);
				if($nflota==0){
					$estado = "<p class='error'>No hay resultados en la consulta de Incidencias</p>\n";
				}
				else{
					$row_incid = mysql_fetch_array($res_incid);
					$id_incid = $row_incid["ID"];
					$estado = "Reparacion - <a href='detalle_incidencia.php?id=$id_incid'><img src='imagenes/consulta.png'></a>";
					$fecha_val = $row_incid["FAVERIA"];
				}
				$fecha_nom = "Fecha de Incidencia";
				break;
			}
		}
	?>
		<TR>
			<TH class="t4c">Estado</TH>
			<TD><?php echo $estado;?></TD>
			<TH class="t4c"><?php echo $fecha_nom;?></TH>
			<TD><?php echo $fecha_val;?></TD>
		</TR>
	<?php
		if ($flota_usu==100){
	?>

                    <TR class="filapar">
                            <TH class="t4c">Nº K</TH>
                            <TD><?php echo $row_terminal["NUMEROK"];?></TD>

                            <TH class="t4c">Carpeta</TH>
                            <TD><?php echo $row_terminal["CARPETA"];?></TD>
                    </TR>
                    <TR>
                                    <TH class="t4c">Observaciones</TH>
                                    <TD colspan='3'><?php echo utf8_encode($row_terminal["OBSERVACIONES"]);?></TD>
                    </TR>
	<?php
		}
		else{
	?>
		
                    <TR class="filapar">
                        <TH class="t4c">Carpeta</TH>
                        <TD><?php echo $row_terminal["CARPETA"];?></TD>
                        <TH class="t4c">Observaciones</TH>
                        <TD><?php echo utf8_encode($row_terminal["OBSERVACIONES"]);?></TD>
                    </TR>
	<?php
		}
	?>
	</table>
	<table>
		<tr>
<?php
		if ($permiso==2){
?>
			<TD class="borde">
				<a href='editar_terminal.php?id=<?php echo $id?>'><img src='imagenes/pencil.png' alt='Editar'></a><br>Editar Terminal
			</TD>			
			<TD class="borde">
		<?php
			if ($row_terminal["ESTADO"]=="B"){
				$ref = "alta_terminal.php?id=$id";
				$img = "imagenes/nuevo.png";
				$txt = "Dar de Alta";
			}
			else{
				$ref = "baja_terminal.php?id=$id";
				$img = "imagenes/eliminar.png";
				$txt = "Dar de Baja";
			}
		?>
				<a href='<?php echo $ref;?>'><img src='<?php echo $img;?>' alt='Editar'></a><br><?php echo $txt;?>
			</TD>
<?php
		}
?>
		</tr>
	</table>
<?php
	}
	else{
?>
	<h1>Acceso denegado</h1>
	<p class='error'>No le está permitido el acceso a los datos de este terminal, pues pertenece a otra flota.</p>
<?php
	}
?>
</body>
</html>
