<?php
// ------------ Obtención del usuario Joomla! --------------------------------------- //
        // Le decimos que estamos en Joomla
        define( '_JEXEC', 1 );

	// Definimos la constante de directorio actual y el separador de directorios (windows server: \ y linux server: /)
	define( 'DS', DIRECTORY_SEPARATOR );
	define('JPATH_BASE', dirname(__FILE__).DS.'..' );

	// Cargamos los ficheros de framework de Joomla 1.5, y las definiciones de constantes (IMPORTANTE AMBAS LÍNEAS)
	require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

	// Iniciamos nuestra aplicación (site: frontend)
	$mainframe =& JFactory::getApplication('site');

	// Obtenemos los parámetros de Joomla
	$user =& JFactory::getUser();
	$usu = $user->username;
// ------------------------------------------------------------------------------------- //

// ------------ Conexión a BBDD de Terminales ----------------------------------------- //
        include("conexion.php");
        $base_datos=$dbbdatos;
        $link=mysql_connect($dbserv,$dbusu,$dbpaso);
        if(!link){
            echo "<b>ERROR MySQL:</b>".mysql_error();
        }
// ------------------------------------------------------------------------------------- //

import_request_variables("gp","");

/* Determinamos si es usuario OFICINA COMDES para ver la gestión de flotas */
$sql_oficina="SELECT ID FROM flotas WHERE LOGIN='$usu'";
$res_oficina=mysql_db_query($base_datos,$sql_oficina);
$row_oficina=mysql_fetch_array($res_oficina);
$flota_usu=$row_oficina["ID"];
/*
 *  $permiso = variable de permisos de flota:
 *      0: Sin permiso
 *      1: Permiso de consulta
 *      2: Permiso de modificación
 */
$permiso=0;
if($flota_usu==100){
    $permiso = 2;
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Editar la Flota COMDES</title>
 <link rel="StyleSheet" type="text/css" href="estilo.css">
</head>
<body>
<?php
	if($permiso==2){
		//datos de la tabla Flotas
		$sql_flota="SELECT * FROM flotas WHERE ID='$id'";
		$res_flota=mysql_db_query($base_datos,$sql_flota) or die ("Error en la consulta de Flota: ".mysql_error());
		$nflota=mysql_num_rows($res_flota);
		if($nflota==0){
			echo "<p class='error'>No hay resultados en la consulta de la Flota</p>\n";
		}
		else{
			$row_flota=mysql_fetch_array($res_flota);
		}
		//datos de la tabla Terminales
		// Tipos de termninales
		$tipos = array("F","M%","MB","MA", "MG", "P%", "PB", "PA", "PX");
		$cabecera = array("Terminales Fijos","Terminales Móviles","Móviles Básicos","Móviles Avanzados", "Móviles Gateway", "Terminales Portátiles", "Portátiles Básicos", "Portátiles Avanzados", "Portátiles ATEX");
		$nterm = array (0,0,0,0,0,0,0,0,0);
		$sql_term = "SELECT * FROM terminales WHERE FLOTA='$id'";
		$res_term = mysql_db_query($base_datos,$sql_term) or die ("Error en la consulta de Terminales".mysql_error());
		$tot_term = mysql_num_rows($res_term);
		for($j=0; $j< count($tipos);$j++){
			$sql_term = "SELECT * FROM terminales WHERE FLOTA='$id' AND TIPO LIKE '".$tipos[$j]."'";
			$res_term = mysql_db_query($base_datos,$sql_term) or die ("Error en la consulta de ".$cabecera[$j].": ".mysql_error());
			$nterm[$j] = mysql_num_rows($res_term);
		}
		//datos de la tabla Municipio
		// INE
		$ine =$row_flota["INE"];	
		############# Enlaces para la exportación #######
		$linkpdf = "pdfflota.php?id=$id";
		$linkxls = "xlsflota.php?id=$id";
		$linkrtf = "rtfflota.php?id=$id";
?>
<h1>Flota <?php echo utf8_encode($row_flota["FLOTA"]);?> (<?php echo $row_flota["ACRONIMO"];?>)</h1>
<form name="formflota" action="update_flota.php" method="POST">
<h2>Datos Administrativos de la Flota</h2>
	<table>
		<TR>
			<TH class="t40p">Nombre</TH>
			<TH class="t5c">Acrónimo</TH>
			<TH class="t5c">Usuario</TH>
			<TH class="t10c">Activa</TH>
			<TH class="t10c">Encriptación</TH>
		</TR>
		<TR>
			<TD><input type="text" name="flota" value="<?php echo utf8_encode($row_flota["FLOTA"]);?>" size="40"></TD>
			<TD><input type="text" name="acronimo" value="<?php echo utf8_encode($row_flota["ACRONIMO"]);?>" size="10"></TD>
			<TD><?php echo $row_flota["LOGIN"];?></TD>
			<TD><?php echo $row_flota["ACTIVO"];?></TD>
                        <TD>
                            <select name="encriptacion">
                                <option value="SI"<?php if ($row_flota["ENCRIPTACION"]=="SI") echo 'selected';?>>SI</option>
                                <option value="NO"<?php if ($row_flota["ENCRIPTACION"]=="NO") echo 'selected';?>>NO</option>
                            </select>
                        </TD>
		</TR>
	</table>
<h2>Datos de Localización de la Flota</h2>
	<table>
		<TR>
			<TH class="t40p">Domicilio</TH>
			<TH class="t5c">C.P.</TH>
			<TH class="t40p">Ciudad</TH>
		</TR>
		<TR>
			<TD>
				<input type="text" name="domicilio" value="<?php echo utf8_encode($row_flota["DOMICILIO"]);?>" size="40">
			</TD>
			<TD><input type="text" name="cp" value="<?php echo $row_flota["CP"];?>" size="10"></TD>
			<TD>
				<select name="ine">
<?php				$sql_mun = "SELECT * FROM municipios ORDER BY MUNICIPIO ASC";
				$res_mun = mysql_db_query($base_datos,$sql_mun) or die ("Error en la consulta de Municipio".mysql_error());
				$nmun = mysql_num_rows($res_mun);
				if($nmun==0){
					echo "<p class='error'>No hay resultados en la consulta del Municipio</p>\n";
				}
				else{
					for ($i=0; $i < $nmun; $i++){
						$row_mun = mysql_fetch_array($res_mun);
						$ine_mun = $row_mun["INE"];
						$nom_mun = utf8_encode($row_mun["MUNICIPIO"]);
?>
					<option value="<?php echo $ine_mun;?>" <?php if ($ine==$ine_mun) echo 'selected';?>>
						<?php echo $nom_mun;?>
					</option>
<?php
					}
				}
?>
				</select>
		</TR>
	</table>
<h2>Contactos de la Flota</h2>
<?php
	if (($row_flota["RESPONSABLE"]=="0")&&($row_flota["CONTACTO1"]=="0")&&($row_flota["CONTACTO2"]=="0")&&($row_flota["CONTACTO3"]=="0")){
?>
		<p class='error'>No hay Contactos para la flota</p>
<?php
	}
	else{
?>
	<table>
		<TR>
			<TD class="t10c">&nbsp;</TD>
			<TH class="t4c">Nombre</TH>
			<TH class="t4c">Cargo</TH>
			<TH class="t10c">Teléfono</TH>
			<TH class="t10c">Móvil</TH>
			<TH class="t5c">Correo Electrónico</TH>
		</TR>

<?php
		$par = 0;
		// Datos de contactos
		$id_contacto = $row_flota["RESPONSABLE"];
		$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
		$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
		$ncontacto=mysql_num_rows($res_contacto);
		if($ncontacto!=0){
			$row_contacto=mysql_fetch_array($res_contacto);
?>
		<TR>
			<TH>Responsable</TH>
			<TD><?php echo utf8_encode($row_contacto["NOMBRE"]);?></TD>
			<TD><?php echo utf8_encode($row_contacto["CARGO"]);?></TD>
			<TD><?php echo utf8_encode($row_contacto["TELEFONO"]);?></TD>
			<TD><?php echo utf8_encode($row_contacto["MOVIL"]);?></TD>
			<TD><?php echo utf8_encode($row_contacto["MAIL"]);?></TD>
		</TR>
	<?php
			$par++;
		
		}
		if ($row_flota["CONTACTO1"]!="0"){
			$id_contacto = $row_flota["CONTACTO1"];
			$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
			$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
			$ncontacto=mysql_num_rows($res_contacto);
			if($ncontacto==0){
				echo "<p class='error'>No hay resultados en la consulta del Contacto 1</p>\n";
			}
			else{
				$row_contacto=mysql_fetch_array($res_contacto);
			}
	?>
			<TR <?php if (($par % 2)==1) echo "class='filapar'";?>>
				<TH>Contacto 1</TH>
				<TD><?php echo utf8_encode($row_contacto["NOMBRE"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["CARGO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["TELEFONO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MOVIL"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MAIL"]);?></TD>
			</TR>
	<?php
			$par++;
		}
		if ($row_flota["CONTACTO2"]!="0"){
			$id_contacto = $row_flota["CONTACTO2"];
			$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
			$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
			$ncontacto=mysql_num_rows($res_contacto);
			if($ncontacto==0){
				echo "<p class='error'>No hay resultados en la consulta del Contacto 2</p>\n";
			}
			else{
				$row_contacto=mysql_fetch_array($res_contacto);
			}
	?>
			<TR <?php if (($par % 2)==1) echo "class='filapar'";?>>
				<TH>Contacto 2</TH>
				<TD><?php echo utf8_encode($row_contacto["NOMBRE"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["CARGO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["TELEFONO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MOVIL"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MAIL"]);?></TD>
			</TR>
	<?php
			$par++;
		}
		if ($row_flota["CONTACTO3"]!="0"){
			$id_contacto = $row_flota["CONTACTO3"];
			$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
			$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
			$ncontacto=mysql_num_rows($res_contacto);
			if($ncontacto==0){
				echo "<p class='error'>No hay resultados en la consulta del Contacto 3</p>\n";
			}
			else{
				$row_contacto=mysql_fetch_array($res_contacto);
			}
	?>
			<TR <?php if (($par % 2)==1) echo "class='filapar'";?>>
				<TH>Contacto 3</TH>
				<TD><?php echo utf8_encode($row_contacto["NOMBRE"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["CARGO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["TELEFONO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MOVIL"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MAIL"]);?></TD>
			</TR>
	<?php
		}
	?>
	</table>
<?php
	}
?>
<h2>Resúmen de Terminales de la Flota</h2>
	<table>
		<TR>
			<TH class="t10c">Total Terminales</TH>
<?php
		for ($i = 0 ; $i < count($tipos); $i++) {
?>
			<TH class="t10c"><?php echo $cabecera[$i];?></TH>
<?php
		}
?>
		</TR>
		<TR>
			<TD class="centro"><?php echo $tot_term;?></TD>
<?php
		for ($i = 0 ; $i < count($tipos); $i++) {
?>
			<TD class="centro"><?php echo $nterm[$i];?></TD>
<?php
		}
?>
		</TR>
	</table>
	<input type="hidden" name="idflota" value="<?php echo $id;?>">
	<input type="hidden" name="flota_org" value="<?php echo utf8_encode($row_flota["FLOTA"]);?>">
	<input type="hidden" name="acro_org" value="<?php echo utf8_encode($row_flota["ACRONIMO"]);?>">
	<input type="hidden" name="origen" value="editar">
	<table>
		<tr>
			<TD class="borde">
				<input type='image' name='action' src='imagenes/guardar.png' alt='Guardar' title="Guardar"><br>Guardar Cambios
			</TD>
			<TD class="borde">
				<a href='detalle_flota.php?id=<?php echo $id;?>'>
					<img src='imagenes/atras.png' alt='Volver' title="Volver">
				</a><br>Volver a detalle
			</TD>
			<TD class="borde">
				<a href='#' onclick='document.formflota.reset();'>
					<img src='imagenes/no.png' alt='Cancelar' title="Cancelar">
				</a><br>Cancelar Cambios
			</TD>
		</tr>
	</table>
</form>
<?php
	}
	else{
?>
	<h1>Acceso denegado</h1>
	<p class='error'>No le está permitido modificar los datos de esta flota.</p>
<?php
	}
?>
</body>
</html>