<?php
// ------------ Obtención del usuario Joomla! --------------------------------------- //
        // Le decimos que estamos en Joomla
        define( '_JEXEC', 1 );

	// Definimos la constante de directorio actual y el separador de directorios (windows server: \ y linux server: /)
	define( 'DS', DIRECTORY_SEPARATOR );
	define('JPATH_BASE', dirname(__FILE__).DS.'..' );

	// Cargamos los ficheros de framework de Joomla 1.5, y las definiciones de constantes (IMPORTANTE AMBAS LÍNEAS)
	require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

	// Iniciamos nuestra aplicación (site: frontend)
	$mainframe =& JFactory::getApplication('site');

	// Obtenemos los parámetros de Joomla
	$user =& JFactory::getUser();
	$usu = $user->username;
// ------------------------------------------------------------------------------------- //

// ------------ Conexión a BBDD de Terminales ----------------------------------------- //
        include("conexion.php");
        $base_datos=$dbbdatos;
        $link=mysql_connect($dbserv,$dbusu,$dbpaso);
        if(!link){
            echo "<b>ERROR MySQL:</b>".mysql_error();
        }
// ------------------------------------------------------------------------------------- //

import_request_variables("gp","");

/* Determinamos si es usuario OFICINA COMDES para ver la gestión de flotas */
$sql_oficina="SELECT ID FROM flotas WHERE LOGIN='$usu'";
$res_oficina=mysql_db_query($base_datos,$sql_oficina);
$row_oficina=mysql_fetch_array($res_oficina);
$flota_usu=$row_oficina["ID"];
/*
 *  $permiso = variable de permisos de flota:
 *      0: Sin permiso
 *      1: Permiso de consulta
 *      2: Permiso de modificación
 */
$permiso=0;
if($flota_usu==100){
    $permiso = 2;
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Contactos de la Flota COMDES</title>
 <link rel="StyleSheet" type="text/css" href="estilo.css">
</head>
<body>
<?php
	if($permiso==2){
		//datos de la tabla Flotas
		$sql_flota="SELECT * FROM flotas WHERE ID='$id'";
		$res_flota=mysql_db_query($base_datos,$sql_flota) or die ("Error en la consulta de Flota: ".mysql_error());
		$nflota=mysql_num_rows($res_flota);
		if($nflota==0){
			echo "<p class='error'>No hay resultados en la consulta de la Flota</p>\n";
		}
		else{
			$row_flota=mysql_fetch_array($res_flota);
		}
?>
<h1>Flota <?php echo utf8_encode($row_flota["FLOTA"]);?> (<?php echo $row_flota["ACRONIMO"];?>)</h1>
	
<h2>Datos Administrativos de la Flota</h2>
	<table>
		<TR>
			<TH class="t40p">Nombre</TH>
			<TH class="t5c">Acrónimo</TH>
			<TH class="t5c">Usuario</TH>
			<TH class="t10c">Activa</TH>
			<TH class="t10c">Encriptación</TH>
		</TR>
		<TR>
			<TD><?php echo utf8_encode($row_flota["FLOTA"]);?></TD>
			<TD><?php echo $row_flota["ACRONIMO"];?></TD>
			<TD><?php echo $row_flota["LOGIN"];?></TD>
			<TD><?php echo $row_flota["ACTIVO"];?></TD>
                        <TD><?php echo $row_flota["ENCRIPTACION"];?></TD>
		</TR>
	</table>
<h2>Contactos de la Flota</h2>
<form name="contacto" action="editar_contacto.php" method="POST">
	<input type="hidden" name="idflota" value="<?php echo $id;?>">
	<input type="hidden" name="flota" value="<?php echo utf8_encode($row_flota["FLOTA"]);?>">
	<input type="hidden" name="acronimo" value="<?php echo utf8_encode($row_flota["ACRONIMO"]);?>">
<table>
	<TR>
		<TD class="t5c">&nbsp;</TD>
		<TH class="t40p">Nombre</TH>
		<TH class="t10c">Detalle</TH>
		<TH class="t10c">Modificar</TH>
		<TH class="t10c">Borrar</TH>
		<TH class="t10c">Nuevo</TH>
	</TR>
<?php
	// Datos de contactos
	$contactos = array ($row_flota["RESPONSABLE"],$row_flota["CONTACTO1"],$row_flota["CONTACTO2"],$row_flota["CONTACTO3"]);
        $nom_contacto = array("Responsable", "Contacto 1", "Contacto 2", "Contacto 3");
        $hid_cont = array("id_resp", "id_cont1", "id_cont2", "id_cont3");
        for ($j = 0; $j < count ($contactos); $j++){
            $ncontacto = 0;
            if ($contactos[$j]!=0){
                $id_contacto = $contactos[$j];
                $sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
		$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
		$ncontacto=mysql_num_rows($res_contacto);
            }
            if($ncontacto!=0){
                $row_contacto=mysql_fetch_array($res_contacto);
?>
                       <TR <?php if (($j % 2)==1) echo "class='filapar'";?>>
                                <TH><?php echo $nom_contacto[$j];?></TH>
                                <TD><?php echo utf8_encode($row_contacto["NOMBRE"]);?></TD>
                                <TD class="centro"><input type='image' name='imgdet' value="<?php echo $nom_contacto[$j];?>" src='imagenes/consulta.png' alt='Detalle' onclick="this.form.detalle.value=this.value"></TD>
                                <TD class="centro"><input type='image' name='imgedir' value="<?php echo $nom_contacto[$j];?>" src='imagenes/editar.png' alt='Modificar' onclick="this.form.editar.value=this.value"></TD>
                                <TD class="centro"><input type='image' name='imgdel' value="<?php echo $nom_contacto[$j];?>" src='imagenes/cancelar.png' alt='Borrar' onclick="this.form.borrar.value=this.value"></TD>
                                <TD class="centro">-</TD>
                        </TR>
                        <input type="hidden" name="<?php echo $hid_cont[$j];?>" value="<?php echo $id_contacto;?>">
<?php
            }
            else{
?>
                    <TR <?php if (($j % 2)==1) echo "class='filapar'";?>>
                            <TH><?php echo $nom_contacto[$j];?></TH>
                            <TD><span class="error">No hay <?php echo $nom_contacto[$j];?> de Flota</span></TD>
                            <TD class="centro">-</TD>
                            <TD class="centro">-</TD>
                            <TD class="centro">-</TD>
                            <TD class="centro"><input type='image' name='imgnew' value="<?php echo $nom_contacto[$j];?>" src='imagenes/nueva.png' alt='Nuevo' onclick="this.form.nuevo.value=this.value"></TD>
                    </TR>
<?php
             }
        }
?>
</table>
         <input type="hidden" name="detalle" value="">
         <input type="hidden" name="editar" value="">
         <input type="hidden" name="borrar" value="">
         <input type="hidden" name="nuevo" value="">
</form>
<table>
	<tr>
		<TD class="borde">
			<a href='detalle_flota.php?id=<?php echo $id;?>'>
				<img src='imagenes/atras.png' alt='Volver' title="Volver">
			</a><br>Volver a detalle
		</TD>
	</tr>
</table>
<?php
	}
	else{
?>
	<h1>Acceso denegado</h1>
	<p class='error'>No le está permitido el acceso a los datos de esta flota, pues no es la suya.</p>
<?php
	}
?>
</body>
</html>