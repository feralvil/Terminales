<?php
//Parametros para la conexión con la BASE DE DATOS.En principio suponemos que existe un único tipo de conexión.
$dbserv='localhost';
$dbbdatos='tcomdes';
$dbusu='tcomdes';
$dbpaso='tc0mdes';
$dbservauth='localhost';
$dbbdatosauth='cvcomdes';
$dbusuauth='cvcomdes';
$dbpasoauth='cvc0mdes';
?>
