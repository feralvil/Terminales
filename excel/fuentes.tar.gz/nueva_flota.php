<?php
// ------------ Obtención del usuario Joomla! --------------------------------------- //
        // Le decimos que estamos en Joomla
        define( '_JEXEC', 1 );

	// Definimos la constante de directorio actual y el separador de directorios (windows server: \ y linux server: /)
	define( 'DS', DIRECTORY_SEPARATOR );
	define('JPATH_BASE', dirname(__FILE__).DS.'..' );

	// Cargamos los ficheros de framework de Joomla 1.5, y las definiciones de constantes (IMPORTANTE AMBAS LÍNEAS)
	require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

	// Iniciamos nuestra aplicación (site: frontend)
	$mainframe =& JFactory::getApplication('site');

	// Obtenemos los parámetros de Joomla
	$user =& JFactory::getUser();
	$usu = $user->username;
// ------------------------------------------------------------------------------------- //

// ------------ Conexión a BBDD de Terminales ----------------------------------------- //
        include("conexion.php");
        $base_datos=$dbbdatos;
        $link=mysql_connect($dbserv,$dbusu,$dbpaso);
        if(!link){
            echo "<b>ERROR MySQL:</b>".mysql_error();
        }
// ------------------------------------------------------------------------------------- //

import_request_variables("gp","");

/* Determinamos si es usuario OFICINA COMDES para ver la gestión de flotas */
$sql_oficina="SELECT ID FROM flotas WHERE LOGIN='$usu'";
$res_oficina=mysql_db_query($base_datos,$sql_oficina);
$row_oficina=mysql_fetch_array($res_oficina);
$flota_usu=$row_oficina["ID"];
/*
 *  $permiso = variable de permisos de flota:
 *      0: Sin permiso
 *      1: Permiso de consulta
 *      2: Permiso de modificación
 */
$permiso=0;
if($flota_usu==100){
    $permiso = 2;
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Nueva Flota COMDES</title>
 <link rel="StyleSheet" type="text/css" href="estilo.css">
</head>
<body>
<?php
	if($permiso==2){
		//datos de la tabla Flotas
		$sql_flotas="SELECT MAX(ID) FROM flotas";
		$res_flotas=mysql_db_query($base_datos,$sql_flotas) or die ("Error en la consulta de Flota: ".mysql_error());
		$nflotas=mysql_num_rows($res_flotas);
		if($nflotas==0){
			echo "<p class='error'>No hay resultados en la consulta de la Flota</p>\n";
		}
		else{

			$row_flota=mysql_fetch_array($res_flotas);
                        $id_flota = $row_flota[0] + 1;
		}
		
?>
<h1>Nueva Flota COMDES</h1>
<form name="formflota" action="update_flota.php" method="POST">
	<input type="hidden" name="idflota" value="<?php echo $id_flota;?>">
	<input type="hidden" name="origen" value="nueva">
<h2>Datos Administrativos de la Flota</h2>
	<table>
		<TR>
			<TH class="t40p">Nombre</TH>
			<TH class="t5c">Acrónimo</TH>
			<TH class="t5c">Usuario</TH>
			<TH class="t10c">Activa</TH>
			<TH class="t10c">Encriptación</TH>
		</TR>
		<TR>
			<TD><input type="text" name="flota" value="" size="50"></TD>
			<TD><input type="text" name="acronimo" value="" size="10"></TD>
			<TD><input type="text" name="usuario" value="" size="15"></TD>
			<TD>
				<select name="activa">
					<option value="SI">SI</option>
					<option value="NO">NO</option>
				</select>
			</TD>
                        <TD>
				<select name="encriptacion">
					<option value="SI">SI</option>
					<option value="NO">NO</option>
				</select>
			</TD>
		</TR>
	</table>
<h2>Datos de Localización de la Flota</h2>
	<table>
		<TR>
			<TH class="t40p">Domicilio</TH>
			<TH class="t5c">C.P.</TH>
			<TH class="t40p">Ciudad</TH>
		</TR>
		<TR>
			<TD>
				<input type="text" name="domicilio" value="" size="40">
			</TD>
			<TD><input type="text" name="cp" value="" size="10"></TD>
			<TD>
				<select name="ine">
<?php				$sql_mun = "SELECT * FROM municipios ORDER BY MUNICIPIO ASC";
				$res_mun = mysql_db_query($base_datos,$sql_mun) or die ("Error en la consulta de Municipio".mysql_error());
				$nmun = mysql_num_rows($res_mun);
				if($nmun==0){
					echo "<p class='error'>No hay resultados en la consulta del Municipio</p>\n";
				}
				else{
					for ($i=0; $i < $nmun; $i++){
						$row_mun = mysql_fetch_array($res_mun);
						$ine_mun = $row_mun["INE"];
						$nom_mun = utf8_encode($row_mun["MUNICIPIO"]);
?>
                                            <option value="<?php echo $ine_mun;?>"><?php echo $nom_mun;?></option>
<?php
					}
				}
?>
				</select>
		</TR>
	</table>
	<table>
		<tr>
			<TD class="borde"><input type='image' name='nueva' src='imagenes/guardar.png' alt='Nueva' title="Nueva"><br>Guardar Flota</TD>
			<TD class="borde"><a href='flotas.php'><img src='imagenes/atras.png' alt='Volver' title="Volver"></a><br>Volver</TD>
			<TD class="borde"><a href='#' onclick='document.formflota.reset();'><img src='imagenes/no.png' alt='Cancelar' title="Cancelar"></a><br>Cancelar Cambios</TD>
		</tr>
	</table>
</form>
<?php
	}
	else{
?>
	<h1>Acceso denegado</h1>
	<p class='error'>No le está permitido añadir una nueva flota.</p>
<?php
	}
?>
</body>
</html>