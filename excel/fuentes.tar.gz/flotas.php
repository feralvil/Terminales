<?php
// ------------ Obtención del usuario Joomla! --------------------------------------- //
        // Le decimos que estamos en Joomla
        define( '_JEXEC', 1 );

	// Definimos la constante de directorio actual y el separador de directorios (windows server: \ y linux server: /)
	define( 'DS', DIRECTORY_SEPARATOR );
	define('JPATH_BASE', dirname(__FILE__).DS.'..' );

	// Cargamos los ficheros de framework de Joomla 1.5, y las definiciones de constantes (IMPORTANTE AMBAS LÍNEAS)
	require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

	// Iniciamos nuestra aplicación (site: frontend)
	$mainframe =& JFactory::getApplication('site');

	// Obtenemos los parámetros de Joomla
	$user =& JFactory::getUser();
	$usu = $user->username;
// ------------------------------------------------------------------------------------- //

// ------------ Conexión a BBDD de Terminales ----------------------------------------- //
        include("conexion.php");
        $base_datos=$dbbdatos;
        $link=mysql_connect($dbserv,$dbusu,$dbpaso);
        if(!link){
            echo "<b>ERROR MySQL:</b>".mysql_error();
        }
// ------------------------------------------------------------------------------------- //

import_request_variables("gp","");

/* Determinamos si es usuario OFICINA COMDES para ver la gestión de flotas */
$sql_oficina="SELECT ID FROM flotas WHERE LOGIN='$usu'";
$res_oficina=mysql_db_query($base_datos,$sql_oficina);
$row_oficina=mysql_fetch_array($res_oficina);
$flota_usu=$row_oficina["ID"];
/*
 *  $permiso = variable de permisos de flota:
 *      0: Sin permiso
 *      1: Permiso de consulta
 *      2: Permiso de modificación
 */
$permiso=0;
if($flota_usu==100){
    $permiso = 2;
}
?>
<html>
<head>
<title>Base de Datos de Terminales de la Red COMDES</title>
<link rel="StyleSheet" type="text/css" href="estilo.css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>
<?php
	if($permiso==2){
?>
<form action="flotas.php" name="formulario" method="POST">
<h4>Criterios de Selección</h4>
<table>
	<TR>
		<TD>
			<select name='flota' onChange='document.formulario.submit();'>
				<option value='00' <?php if (($flota=="00")||($flota=="")) echo ' selected';?>>Flota</option>
	<?php
		$sql_flotas = "SELECT ID, flotas.FLOTA, ACRONIMO, ENCRIPTACION FROM flotas";
		$res_flotas=mysql_db_query($base_datos,$sql_flotas) or die(mysql_error());
		$nflotas=mysql_num_rows($res_flotas);
		for ($i=0;$i<$nflotas;$i++){
			$row_flota = mysql_fetch_array($res_flotas);
	?>
				<option value='<?php echo $row_flota[0];?>' <?php if ($flota==$row_flota[0]) echo ' selected';?>><?php echo utf8_encode($row_flota[1]);?></option>
	<?php
		}
	?>
			</select>
		</TD>
	</TR>
</table>
	<?php
		if ($tam_pagina==""){
			$tam_pagina=10;
		}
		if(!$pagina){
			$inicio=0;
			$pagina=1;
		}
		else{
			$inicio=($pagina-1)*$tam_pagina;
		}
		if (($flota!='')&&($flota!="00")){
			$sql_flotas=$sql_flotas." WHERE (flotas.ID='$flota')";
		}
		$sql_no_limit=$sql_flotas." ORDER BY flotas.FLOTA ASC";
		$sql_limit=$sql_no_limit." LIMIT ".$inicio.",".$tam_pagina.";";
		$res=mysql_db_query($base_datos,$sql_no_limit) or die(mysql_error());
		$nfilas=mysql_num_rows($res);
		$total_pag=ceil($nfilas/$tam_pagina);
		############# Enlaces para la exportación #######
		$linkpdf = "pdfflotas.php?flota=$flota";
		$linkxls = "xlsflotas.php?flota=$flota";
		$linkrtf = "rtfflotas.php?flota=$flota";
	?>
<h4>Resultado de la búsqueda</h4>
<table>
	<tr class="borde">
		<td class="borde">Nº total de registros: <b><?php echo $nfilas;?></b>.</td>
		<td class="borde">
			Mostrar:
			<select name='tam_pagina' onChange='document.formulario.submit();'>
			<?php
				echo "<option value='10' ";
				if (($tam_pagina=="10") || ($tam_pagina=="")) {
					echo 'selected';
				}
				echo ">10</option>\n";
				echo "<option value='20' ";
				if ($tam_pagina=="20") {
					echo 'selected';
				}
				echo ">20</option>\n";
				echo "<option value='30' ";
				if ($tam_pagina=="30") {
					echo 'selected';
				}
				echo ">30</option>\n";
				echo "<option value='$nfilas' ";
				if ($tam_pagina=="$nfilas") {
					echo 'selected';
				}
				echo ">Todos</option>\n";
			?>
			</select> registros por página
		</td>
		<td class="borde">
		<?php
			if ($total_pag>1){
				echo "Página: \n";
				echo "<select name='pagina' onChange='document.formulario.submit();'>\n";
				for($k=1;$k<=$total_pag;$k++){
					echo "<option value='$k' ";
					if ($pagina==$k) {
						echo 'selected';
					}
					echo ">$k</option>\n";
				}
				echo "</select>\n";
				echo " de $total_pag\n";
			}
		?>
		</td>
		<td class="borde">
			<a href="nueva_flota.php"><img src="imagenes/nueva.png" alt="Nueva Flota"></a> &mdash; Nueva Flota
		</td>
<?php
	if($nfilas>0){
?>
		<td class="borde">
			<a href="<?php echo $linkpdf;?>"><img src="imagenes/pdf.png" alt="PDF" title="PDF"></a> &mdash;
			<a href="<?php echo $linkxls;?>"><img src="imagenes/xls.png" alt="Excel" title="XLS (Excel)"></a> &mdash;
			<a href="<?php echo $linkrtf;?>"><img src="imagenes/rtf.png" alt="RTF (Word)" title="RTF (Word)"></a>
		</td>
<?php
	}
?>
	</tr>
</table>
</form>
<table>
<?php
if ($nfilas==0){
	echo "<tr><td class='borde'>No hay registros</tr></td>";
}
else {
	if($res2=mysql_db_query($base_datos,$sql_limit)){
		$nfilas2=mysql_num_rows($res2);
		$ncampos=mysql_num_fields($res2);
		//*TABLA CON RESULTADOS*//
		echo "<tr>\n";
		//* CABECERA  *//
		$campos=array("Detalle","Flota","Acrónimo","Encriptación","Total Terminales","T. Portátiles","T. Móviles","T. Base");
		for($i=0;$i<count($campos);$i++){
			echo "<th>";
			echo $campos[$i];
			echo "</th>\n";
		}
		echo "</tr>\n";
		$fila=mysql_fetch_array($res2);
		for($i=0;$i<$nfilas2;$i++){
			echo "<tr";
			if (($i % 2) == 1){
				echo " class='filapar'";
			}
			echo ">\n";
			for($j=0;$j<$ncampos;$j++){
				$campo_num=mysql_field_name($res2,$j);
				if($campo_num=="ID"){   //enlace a detalle
					echo "<td class='centro'>";
	                		echo "<a href='detalle_flota.php?id=$fila[0]'>";
					echo "<img src='imagenes/consulta.png'></a>";
				}
				else{
					echo "<td>".utf8_encode($fila[$campo_num]);
				}
				echo "</td>\n";
			} //segundo for
			//datos de la tabla Terminales
			// Tipos de termninales
			$tipos = array("F","M%", "P%");
			$nterm = array (0,0,0);
			$sql_term = "SELECT * FROM terminales WHERE FLOTA='$fila[0]'";
			$res_term = mysql_db_query($base_datos,$sql_term) or die ("Error en la consulta de Terminales".mysql_error());
			$tot_term = mysql_num_rows($res_term);
			echo "<td class='centro'>$tot_term</td>\n";
			for($j=0; $j< count($tipos);$j++){
				$sql_term = "SELECT * FROM terminales WHERE FLOTA='$fila[0]' AND TIPO LIKE '".$tipos[$j]."'";
				$res_term = mysql_db_query($base_datos,$sql_term) or die ("Error en la consulta de ".$cabecera[$j].": ".mysql_error());
				$nterm[$j] = mysql_num_rows($res_term);
				echo "<td class='centro'>$nterm[$j]</td>\n";
			}
			echo "</tr>\n";
			$fila=mysql_fetch_array($res2);
		} //primer for
		
	}
	else {
		echo "<b>ERROR:</b> ".mysql_error(); // si hay error en select_limit
	}
}
?>
</table>
<?php
	} // Si el usuario no es el de la Oficina
	else {
?>
	<h1>Acceso denegado</h1>
        <p class='error'>No le está permitido el acceso a los datos del conjunto de flotas. Usted sólo puede acceder a los datos de su flota: <a href="detalle_flota.php"><img src="imagenes/ir.png" alt="Ir"></a></p>
<?php
	}
?>
</body>
</html>
