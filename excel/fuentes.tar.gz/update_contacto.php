<?php
// ------------ Obtención del usuario Joomla! --------------------------------------- //
        // Le decimos que estamos en Joomla
        define( '_JEXEC', 1 );

	// Definimos la constante de directorio actual y el separador de directorios (windows server: \ y linux server: /)
	define( 'DS', DIRECTORY_SEPARATOR );
	define('JPATH_BASE', dirname(__FILE__).DS.'..' );

	// Cargamos los ficheros de framework de Joomla 1.5, y las definiciones de constantes (IMPORTANTE AMBAS LÍNEAS)
	require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

	// Iniciamos nuestra aplicación (site: frontend)
	$mainframe =& JFactory::getApplication('site');

	// Obtenemos los parámetros de Joomla
	$user =& JFactory::getUser();
	$usu = $user->username;
// ------------------------------------------------------------------------------------- //

// ------------ Conexión a BBDD de Terminales ----------------------------------------- //
        include("conexion.php");
        $base_datos=$dbbdatos;
        $link=mysql_connect($dbserv,$dbusu,$dbpaso);
        if(!link){
            echo "<b>ERROR MySQL:</b>".mysql_error();
        }
// ------------------------------------------------------------------------------------- //

import_request_variables("gp","");

/* Determinamos si es usuario OFICINA COMDES para ver la gestión de flotas */
$sql_oficina="SELECT ID FROM flotas WHERE LOGIN='$usu'";
$res_oficina=mysql_db_query($base_datos,$sql_oficina);
$row_oficina=mysql_fetch_array($res_oficina);
$flota_usu=$row_oficina["ID"];
/*
 *  $permiso = variable de permisos de flota:
 *      0: Sin permiso
 *      1: Permiso de consulta
 *      2: Permiso de modificación
 */
$permiso=0;
if($flota_usu==100){
    $permiso = 2;
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Actualización de Contacto de Flota COMDES</title>
 <link rel="StyleSheet" type="text/css" href="estilo.css">
</head>
<body>
<?php
	if($permiso==2){
		//----------------------- Editar un contacto --------------------------------------------------------------//
		if (($editar=="Responsable")||($editar=="Contacto 1")||($editar=="Contacto 2")||($editar=="Contacto 3")){
			if ($editar=="Responsable"){
				$id_contacto = $id_resp;
			}
			if ($editar=="Contacto 1"){
				$id_contacto = $id_cont1;
			}
			if ($editar=="Contacto 2"){
				$id_contacto = $id_cont2;
			}
			if ($editar=="Contacto 3"){
				$id_contacto = $id_cont3;
			}
			$titulo = "Modificar los datos del $editar de la Flota $flota ($acronimo)";
			$nombre = utf8_decode($nombre);
			$cargo = utf8_decode($cargo);
			$sql_update = "UPDATE contactos SET NOMBRE='$nombre', NIF='$nif', CARGO='$cargo', ";
			$sql_update = $sql_update."TELEFONO='$telefono', TLFGVA='$tlf_gva', MOVIL='$movil', MOVILGVA='$movilgva', ";
			$sql_update = $sql_update."FAX='$fax', MAIL='$mail' WHERE ID=$id_contacto";
			$mensaje = "Los datos del contacto se han modificado correctamente.";
			$error = "Error al modificar los datos:";
		}
		//----------------------- Borrar un contacto --------------------------------------//
		if (($borrar=="Responsable")||($borrar=="Contacto 1")||($borrar=="Contacto 2")||($borrar=="Contacto 3")){
			if ($borrar=="Responsable"){
				$id_contacto = $id_resp;
				$campo = "RESPONSABLE";
			}
			if ($borrar=="Contacto 1"){
				$id_contacto = $id_cont1;
				$campo = "CONTACTO1";
			}
			if ($borrar=="Contacto 2"){
				$id_contacto = $id_cont2;
				$campo = "CONTACTO2";
			}
			if ($borrar=="Contacto 3"){
				$id_contacto = $id_cont3;
				$campo = "CONTACTO3";
			}
			$titulo = "Borrar el $borrar de la Flota $flota ($acronimo)";
			$sql_update = "UPDATE flotas SET $campo=0 WHERE ID=$idflota";
			$mensaje = "$borrar borrado de la Flota correctamente.";
			$error = "Error al borrar el $borrar:";
		}
		//----------------------- Añadir un contacto existente --------------------------------------------------------------//
		if (($nuevoexist=="Responsable")||($nuevoexist=="Contacto 1")||($nuevoexist=="Contacto 2")||($nuevoexist=="Contacto 3")){
			if ($nuevoexist=="Responsable"){
				$campo = "RESPONSABLE";
			}
			if ($nuevoexist=="Contacto 1"){
				$campo = "CONTACTO1";
			}
			if ($nuevoexist=="Contacto 2"){
				$campo = "CONTACTO2";
			}
			if ($nuevoexist=="Contacto 3"){
				$campo = "CONTACTO3";
			}
			$titulo = "Añadir un contacto existente como $nuevoexist a la Flota $flota ($acronimo)";
			$sql_update = "UPDATE flotas SET $campo=$contactoexist WHERE ID=$idflota";
			$mensaje = "$nuevoexist añadido a la Flota correctamente.";
			$error = "Error al añadir el $nuevoexist:";
		}
		//----------------------- Añadir un nuevo contacto --------------------------------------------------------------//
		if (($nuevo=="Responsable")||($nuevo=="Contacto 1")||($nuevo=="Contacto 2")||($nuevo=="Contacto 3")){
			if ($nuevo=="Responsable"){
				$campo = "RESPONSABLE";
			}
			if ($nuevo=="Contacto 1"){
				$campo = "CONTACTO1";
			}
			if ($nuevo=="Contacto 2"){
				$campo = "CONTACTO2";
			}
			if ($nuevo=="Contacto 3"){
				$campo = "CONTACTO3";
			}
			$sql_maxid = "SELECT MAX(ID) FROM contactos";
			$res_maxid=mysql_db_query($base_datos,$sql_maxid) or die(mysql_error());
			$row_maxid = mysql_fetch_array($res_maxid);
			$id_contacto=$row_maxid[0]+1;
			$titulo = "Añadir nuevo contacto como $nuevo a la Flota $flota ($acronimo)";
			$nombre = utf8_decode($nombre);
			$cargo = utf8_decode($cargo);
			$sql_cont = "INSERT INTO contactos (ID, NOMBRE, NIF, CARGO, TELEFONO, TLFGVA, MOVIL, MOVILGVA, FAX, MAIL)";
			$sql_cont = $sql_cont." VALUES ('$id_contacto', '$nombre', '$nif', '$cargo', '$telefono', ";
			$sql_cont = $sql_cont."'$tlf_gva', '$movil', '$movilgva', '$fax', '$mail')";
			$res_cont=mysql_db_query($base_datos,$sql_cont) or die(mysql_error());
			$mensaje = "Nuevo contacto añadido como $nuevo correctamente.";
			$error = "Error al añadir el $nuevo:";
			$sql_update = "UPDATE flotas SET $campo=$id_contacto WHERE ID=$idflota";
		}
		$res_update=mysql_db_query($base_datos,$sql_update);
?>
<h1><?php echo $titulo;?></h1>
	<div class="centro">
<?php
		if ($res_update){
?>
			<p><img src='imagenes/clean.png' alt='OK'></p>
			<p><?php echo $mensaje;?></p>
			<p><a href="detalle_flota.php?id=<?php echo $idflota?>"><img src='imagenes/atras.png' alt='Volver'></a><BR>Volver</p>
<?php
		}
		else {
?>
			<p><img src='imagenes/error.png' alt='Error'></p>
			<p class="error"><?php echo $error;?> <?php echo mysql_error();?></p>
			<p><a href="detalle_flota.php?id=<?php echo $idflota?>"><img src='imagenes/atras.png' alt='Volver'></a><BR>Volver</p>
<?php
		}
?>
	</div>
<?php
	}
	else{
?>
	<h1>Acceso denegado</h1>
	<p class='error'>No le está permitido modificar los datos del Contacto</p>
<?php
	}
?>
</body>
</html>
