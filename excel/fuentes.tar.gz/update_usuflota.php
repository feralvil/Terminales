<?php
// ------------ Obtención del usuario Joomla! --------------------------------------- //
        // Le decimos que estamos en Joomla
        define( '_JEXEC', 1 );

	// Definimos la constante de directorio actual y el separador de directorios (windows server: \ y linux server: /)
	define( 'DS', DIRECTORY_SEPARATOR );
	define('JPATH_BASE', dirname(__FILE__).DS.'..' );

	// Cargamos los ficheros de framework de Joomla 1.5, y las definiciones de constantes (IMPORTANTE AMBAS LÍNEAS)
	require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

	// Iniciamos nuestra aplicación (site: frontend)
	$mainframe =& JFactory::getApplication('site');

	// Obtenemos los parámetros de Joomla
	$user =& JFactory::getUser();
	$usu = $user->username;
// ------------------------------------------------------------------------------------- //

// ------------ Conexión a BBDD de Terminales ----------------------------------------- //
        include("conexion.php");
        $base_datos=$dbbdatos;
        $link=mysql_connect($dbserv,$dbusu,$dbpaso);
        if(!link){
            echo "<b>ERROR MySQL:</b>".mysql_error();
        }
// ------------------------------------------------------------------------------------- //

import_request_variables("gp","");

/* Determinamos si es usuario OFICINA COMDES para ver la gestión de flotas */
$sql_oficina="SELECT ID FROM flotas WHERE LOGIN='$usu'";
$res_oficina=mysql_db_query($base_datos,$sql_oficina);
$row_oficina=mysql_fetch_array($res_oficina);
$flota_usu=$row_oficina["ID"];
/*
 *  $permiso = variable de permisos de flota:
 *      0: Sin permiso
 *      1: Permiso de consulta
 *      2: Permiso de modificación
 */
$permiso=0;
if($flota_usu==100){
    $permiso = 2;
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Actualización del Terminal COMDES</title>
 <link rel="StyleSheet" type="text/css" href="estilo.css">
</head>
<body>
<?php
	if($permiso==2){
		$enlace = "detalle_flota.php?id=$idflota";
		if($origen=="eliminar"){
			$titulo = "Eliminar permisos de Acceso de la Flota $flota_org ($acro_org)";
			$sql_update = "DELETE FROM usuarios_flotas WHERE NOMBRE='$usuflota' AND ID_FLOTA='$flota'";
			$mensaje = "Pemiso de Acceso eliminado";
			$error = "Error al eliminar el permiso:";
		}
		if($origen=="agregar"){
                        $titulo = "Agregar permisos de Acceso de la Flota $flota_org ($acro_org)";
			$sql_update = "INSERT INTO usuarios_flotas (NOMBRE, ID_FLOTA) VALUES ('$usuflota', '$flota')";
			$mensaje = "Pemiso de Acceso añadido";
			$error = "Error al añadir el permiso:";
		}
                $res_update=mysql_db_query($base_datos,$sql_update);
?>
<h1><?php echo $titulo;?></h1>
	<div class="centro">
<?php
		if ($res_update){
?>
			<p><img src='imagenes/clean.png' alt='OK'></p>
			<p><?php echo $mensaje;?></p>
			<p><a href="<?php echo $enlace;?>"><img src='imagenes/atras.png' alt='Volver' title="Volver"></a><BR>Volver</p>
<?php
		}
		else {
?>
			<p><img src='imagenes/error.png' alt='Error'></p>
			<p class="error"><?php echo $error;?> <?php echo mysql_error();?></p>
			<p><a href="<?php echo $enlace;?>"><img src='imagenes/atras.png' alt='Volver' title="Volver"></a><BR>Volver</p>
<?php
		}
?>
	</div>
<?php
	}
	else{
?>
	<h1>Acceso denegado</h1>
	<p class='error'>No le está permitido modificar los permisos de la flota.</p>
<?php
	}
?>
</body>
</html>
