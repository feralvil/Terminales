<?php
// ------------ Obtención del usuario Joomla! --------------------------------------- //
        // Le decimos que estamos en Joomla
        define( '_JEXEC', 1 );

	// Definimos la constante de directorio actual y el separador de directorios (windows server: \ y linux server: /)
	define( 'DS', DIRECTORY_SEPARATOR );
	define('JPATH_BASE', dirname(__FILE__).DS.'..' );

	// Cargamos los ficheros de framework de Joomla 1.5, y las definiciones de constantes (IMPORTANTE AMBAS LÍNEAS)
	require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

	// Iniciamos nuestra aplicación (site: frontend)
	$mainframe =& JFactory::getApplication('site');

	// Obtenemos los parámetros de Joomla
	$user =& JFactory::getUser();
	$usu = $user->username;
// ------------------------------------------------------------------------------------- //

// ------------ Conexión a BBDD de Terminales ----------------------------------------- //
        include("conexion.php");
        $base_datos=$dbbdatos;
        $link=mysql_connect($dbserv,$dbusu,$dbpaso);
        if(!link){
            echo "<b>ERROR MySQL:</b>".mysql_error();
        }
// ------------------------------------------------------------------------------------- //

import_request_variables("gp","");

/* Determinamos si es usuario OFICINA COMDES para ver la gestión de flotas */
$sql_oficina="SELECT ID FROM flotas WHERE LOGIN='$usu'";
$res_oficina=mysql_db_query($base_datos,$sql_oficina);
$row_oficina=mysql_fetch_array($res_oficina);
$flota_usu=$row_oficina["ID"];
/*
 *  $permiso = variable de permisos de flota:
 *      0: Sin permiso
 *      1: Permiso de consulta
 *      2: Permiso de modificación
 */
$permiso=0;
if($flota_usu==100){
    $permiso = 2;
}
?>
<html>
<head>
<title>Acceso a Flotas COMDES</title>
<link rel="StyleSheet" type="text/css" href="estilo.css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>
<?php
	if($permiso!=0){
		//datos de la tabla Flotas
		$sql_flota="SELECT * FROM flotas WHERE ID='$id'";
		$res_flota=mysql_db_query($base_datos,$sql_flota) or die ("Error en la consulta de Flota: ".mysql_error());
		$nflota=mysql_num_rows($res_flota);
		if($nflota==0){
			echo "<p class='error'>No hay resultados en la consulta de la Flota</p>\n";
		}
		else{
			$row_flota=mysql_fetch_array($res_flota);
                        $usuario = $row_flota["LOGIN"];
		}
?>
<h1>Permisos de la Flota <?php echo utf8_encode($row_flota["FLOTA"]);?></h1>
<h2>Datos Administrativos de la Flota</h2>
	<table>
		<TR>
			<TH class="t40p">Nombre</TH>
			<TH class="t5c">Acrónimo</TH>
			<TH class="t5c">Usuario</TH>
			<TH class="t10c">Activa</TH>
			<TH class="t10c">Encriptación</TH>
		</TR>
		<TR>
			<TD><?php echo utf8_encode($row_flota["FLOTA"]);?></TD>
			<TD><?php echo $row_flota["ACRONIMO"];?></TD>
			<TD><?php echo $row_flota["LOGIN"];?></TD>
			<TD><?php echo $row_flota["ACTIVO"];?></TD>
                        <TD><?php echo $row_flota["ENCRIPTACION"];?></TD>
		</TR>
	</table>
<form action="update_usuflota.php" name="formulario" method="POST">
<h2>Seleccione la flotas a las que se desea añadir acceso</h2>
	<?php
                $sql_flotas = "SELECT * FROM flotas ORDER BY flotas.FLOTA ASC";
		$res_flotas=mysql_db_query($base_datos,$sql_flotas) or die(mysql_error());
		$nflotas = mysql_num_rows($res_flotas);
	?>
                <select name="flota">
<?php
                for ($i = 0; $i < $nflotas; $i++){
                    $row_flotas = mysql_fetch_array($res_flotas);
                    $id_perm = $row_flotas["ID"];
                    $sql_perm = "SELECT * FROM usuarios_flotas WHERE NOMBRE ='$usuario' AND ID_FLOTA='$id_perm'";
                    $res_perm = mysql_db_query($base_datos, $sql_perm) or die(mysql_error());
                    $nperm = mysql_num_rows($res_perm);
                    if (($nperm==0)&&($id_perm!=100)) {
?>
                        <option value="<?php echo $row_flotas["ID"];?>">
                            <?php echo utf8_encode($row_flotas["FLOTA"]);?>
                        </option>
<?php                
                    }
                }
?>
                </select>
                <input type="hidden" name="origen" value="agregar">
                <input type="hidden" name="idflota" value="<?php echo $id;?>">
                <input type="hidden" name="usuflota" value="<?php echo $row_flota["LOGIN"];?>">
                <input type="hidden" name="flota_org" value="<?php echo utf8_encode($row_flota["FLOTA"]);?>">
                <input type="hidden" name="acro_org" value="<?php echo utf8_encode($row_flota["ACRONIMO"]);?>">
	<table>
		<tr>
                    <TD class="borde">
                        <input type='image' name='action' src='imagenes/activa.png' alt='Agregar' title="Agregar"><br>Agregar acceso
                    </TD>
                    <td class="borde">
                        <a href='detalle_flota.php?id=<?php echo $id?>'><img src='imagenes/atras.png' alt='Listado'></a><br>Volver a Detalle
                    </td>
		</tr>
	</table>
</form>
<?php
	} // Si el usuario no es el de la Oficina
	else {
?>
            <h1>Acceso denegado</h1>
            <p class='error'>No le está permitido agregar el acceso a otras flotas<a href="detalle_flota.php"><img src="imagenes/ir.png" alt="Ir"></a></p>
<?php
	}
?>
</body>
</html>
