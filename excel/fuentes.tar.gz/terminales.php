<?php
// ------------ Obtención del usuario Joomla! --------------------------------------- //
        // Le decimos que estamos en Joomla
        define( '_JEXEC', 1 );

	// Definimos la constante de directorio actual y el separador de directorios (windows server: \ y linux server: /)
	define( 'DS', DIRECTORY_SEPARATOR );
	define('JPATH_BASE', dirname(__FILE__).DS.'..' );

	// Cargamos los ficheros de framework de Joomla 1.5, y las definiciones de constantes (IMPORTANTE AMBAS LÍNEAS)
	require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

	// Iniciamos nuestra aplicación (site: frontend)
	$mainframe =& JFactory::getApplication('site');

	// Obtenemos los parámetros de Joomla
	$user =& JFactory::getUser();
	$usu = $user->username;
// ------------------------------------------------------------------------------------- //

// ------------ Conexión a BBDD de Terminales ----------------------------------------- //
        include("conexion.php");
        $base_datos=$dbbdatos;
        $link=mysql_connect($dbserv,$dbusu,$dbpaso);
        if(!link){
            echo "<b>ERROR MySQL:</b>".mysql_error();
        }
// ------------------------------------------------------------------------------------- //

import_request_variables("gp","");

/* Determinamos si es usuario OFICINA COMDES para ver la gestión de flotas */
$sql_oficina="SELECT ID FROM flotas WHERE LOGIN='$usu'";
$res_oficina=mysql_db_query($base_datos,$sql_oficina);
$row_oficina=mysql_fetch_array($res_oficina);
$flota_usu=$row_oficina["ID"];
$permiso = 0;
if($flota_usu==100){
    $permiso = 2;
}
else {
    $sql_permiso = "SELECT * FROM usuarios_flotas WHERE NOMBRE='$usu'";
    $res_permiso = mysql_db_query($base_datos,$sql_permiso) or die(mysql_error());
    $npermiso = mysql_num_rows($res_permiso);
    if ($npermiso > 1){
        $permiso = 1;
    }
}
?>
<html>
<head>
<title>Base de Datos de Terminales de la Red COMDES</title>
<link rel="StyleSheet" type="text/css" href="estilo.css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>
<h1>Terminales de la Red COMDES</h1>
<form action="terminales.php" name="formulario" method="POST">
<h4>Criterios de Selección/Búsqueda</h4>
<table>
	<TR>
	<?php
		if($permiso!=0){
	?>		<TD>
			<select name='flota' onChange='document.formulario.submit();'>
				<option value='NN' <?php if (($flota=="NN")||($flota=="")) echo ' selected';?>>Flota</option>
	<?php
                                if ($permiso==2){
                                    $sql_flotas = "SELECT ID, ACRONIMO FROM flotas";
                                }
                                else{
                                    $sql_flotas = "SELECT ID, ACRONIMO FROM flotas, usuarios_flotas WHERE ";
                                    $sql_flotas = $sql_flotas."usuarios_flotas.NOMBRE='$usu' AND flotas.ID = usuarios_flotas.ID_FLOTA";
                                }
				$res_flotas=mysql_db_query($base_datos,$sql_flotas) or die(mysql_error());
				$nflotas=mysql_num_rows($res_flotas);
                                $flotas = array();
				for ($i=0;$i<$nflotas;$i++){
					$row_flota = mysql_fetch_array($res_flotas);
                                        $flotas[$i] = $row_flota[0];
	?>
				<option value='<?php echo $row_flota[0];?>' <?php if ($flota==$row_flota[0]) echo ' selected';?>><?php echo $row_flota[1];?></option>
	<?php
				}
	?>
			</select>
			</TD>
	<?php
		}
	?>
		<TD>
			<select name="tipoterm" onChange="document.formulario.submit();">
				<option value="00" <?php if (($tipoterm=="00")||($tipoterm=="")) echo 'selected'; ?>>Tipo de Terminal</option>
				<option value="F" <?php if ($tipoterm=="F") echo 'selected'; ?>>Fijo</option>
				<option value="M%" <?php if ($tipoterm=="M%") echo 'selected'; ?>>Móvil</option>
				<option value="MB" <?php if ($tipoterm=="MB") echo 'selected'; ?>>- Móvil Básico</option>
				<option value="MA" <?php if ($tipoterm=="MA") echo 'selected'; ?>>- Móvil Avanzado</option>
				<option value="MG" <?php if ($tipoterm=="MG") echo 'selected'; ?>>- Móvil Gateway/ Repeater</option>
				<option value="P%" <?php if ($tipoterm=="P%") echo 'selected'; ?>>Portátil</option>
				<option value="PB" <?php if ($tipoterm=="PB") echo 'selected'; ?>>- Portátil Básico</option>
				<option value="PA" <?php if ($tipoterm=="PA") echo 'selected'; ?>>- Portátil Avanzado</option>
				<option value="PX" <?php if ($tipoterm=="PX") echo 'selected'; ?>>- Portátil ATEX</option>
			</select>
		</TD>
		<TD>
			<select name="marca" onChange="document.formulario.submit();">
				<option value="00" <?php if (($marca=="00")||($marca=="")) echo 'selected'; ?>>Marca del Terminal</option>
				<?php
					$sql_marca = "SELECT DISTINCT MARCA FROM terminales ORDER BY MARCA ASC";
					$res_marca = mysql_db_query($base_datos,$sql_marca) or die(mysql_error());
					$nmarca = mysql_num_rows($res_marca);
					for ($i=0; $i<$nmarca; $i++){
						$row_marca = mysql_fetch_array($res_marca);
						if ($row_marca[0]!=""){
							echo '<option value="'.$row_marca[0].'"';
							if ($marca==$row_marca[0]) echo 'selected';
							echo ">".$row_marca[0]."</option>\n";
						}
					}
				?>
			</select>
		</TD>
		<TD>
			<select name="estado" onChange="document.formulario.submit();">
				<option value="00" <?php if (($estado=="00")||($estado=="")) echo 'selected'; ?>>Estado</option>
				<option value="A" <?php if ($estado=="NO") echo 'selected'; ?>>Alta</option>
				<option value="B" <?php if ($estado=="SEMID") echo 'selected'; ?>>Baja</option>
				<option value="R" <?php if ($estado=="DUPLEX") echo 'selected'; ?>>Reparación</option>
			</select>
		</TD>
        </TR>
        <TR>
        <?php
           if($permiso != 0){
       ?>
                <td>&nbsp;</td>
       <?php
            }
	?>
                <TD>
                    ISSI:&#160;<input type="text" name="issi" size="20">&#160;<input type='image' name='action' src="imagenes/consulta.png">
		</TD>
                <TD>
                    TEI:&#160;<input type="text" name="tei" size="20">&#160;<input type='image' name='action' src="imagenes/consulta.png">
		</TD>
                <TD>
                    Nº Serie:&#160;<input type="text" name="nserie" size="20">&#160;<input type='image' name='action' src="imagenes/consulta.png">
		</TD>
        </TR>
        <TR>
        <?php
           if($permiso != 0){
       ?>
                <td>&nbsp;</td>
       <?php
            }
	?>
		<TD>
			<select name="amarco" onChange="document.formulario.submit();">
				<option value="00" <?php if (($amarco=="00")||($amarco=="")) echo 'selected'; ?>>Acuerdo Marco</option>
				<option value="SI" <?php if ($amarco=="SI") echo 'selected'; ?>>Sí</option>
				<option value="NO" <?php if ($amarco=="NO") echo 'selected'; ?>>No</option>
			</select>
		</TD>
                <TD>
			<select name="dots" onChange="document.formulario.submit();">
				<option value="00" <?php if (($dots=="00")||($dots=="")) echo 'selected'; ?>>Alta en el DOTS</option>
				<option value="SI" <?php if ($dots=="SI") echo 'selected'; ?>>Sí</option>
				<option value="NO" <?php if ($dots=="NO") echo 'selected'; ?>>No</option>
			</select>
		</TD>
		<TD>
			<select name="permisos" onChange="document.formulario.submit();">
				<option value="00" <?php if (($permisos=="00")||($permisos=="")) echo 'selected'; ?>>Llamadas individuales</option>
				<option value="NO" <?php if ($permisos=="NO") echo 'selected'; ?>>No</option>
				<option value="SEMID" <?php if ($permisos=="SEMID") echo 'selected'; ?>>Semi-dúplex</option>
				<option value="DUPLEX" <?php if ($permisos=="DUPLEX") echo 'selected'; ?>>Dúplex</option>
				<option value="SYD" <?php if ($permisos=="SYD") echo 'selected'; ?>>Ambos</option>
			</select>
		</TD>
	</TR>
</table>
<?php
if ($tam_pagina==""){
	$tam_pagina=30;
}
if(!$pagina){
	$inicio=0;
	$pagina=1;
}
else{
	 $inicio=($pagina-1)*$tam_pagina;
}
$sql = "SELECT terminales.ID, flotas.ACRONIMO, terminales.ISSI, terminales.TEI, terminales.TIPO, ";
$sql=$sql."terminales.MARCA, terminales.MODELO, terminales.PROVEEDOR, terminales.DOTS, ";
$sql=$sql."terminales.AM, terminales.MNEMONICO, terminales.DUPLEX, terminales.SEMID ";
$sql=$sql."FROM terminales, flotas ";
$sql=$sql."WHERE (terminales.FLOTA = flotas.ID) ";
if ($permiso == 2){
	if (($flota!='')&&($flota!="NN")){
		$sql=$sql."AND (terminales.FLOTA='$flota') ";
	}
}
elseif ($permiso == 1){
	if (($flota!='')&&($flota!="NN")){
		$sql=$sql."AND (terminales.FLOTA='$flota') ";
	}
        else {
            $sql = $sql. "AND terminales.FLOTA IN (";
            for ($i = 0; $i < $nflotas; $i++){
                $sql = $sql.$flotas[$i];
                if ($i<($nflotas-1)){
                    $sql = $sql.",";
                }
            }
            $sql = $sql.") ";
        }
}
else{
	$sql=$sql."AND (terminales.FLOTA='$flota_usu') ";
}
if (($tei!='')||($issi!='')||($nserie!='')){
	$amarco = $tipoterm = $marca = $dots = "00";
	if ($tei!=''){
		$sql=$sql."AND (terminales.TEI='$tei') ";
	}
	if ($issi!=''){
		$sql=$sql."AND (terminales.ISSI='$issi') ";
	}
        if ($nserie!=''){
                    $sql=$sql."AND (terminales.NSERIE='$nserie') ";
	}
}
if (($amarco!='')&&($amarco!="00")){
	$sql=$sql."AND (terminales.AM='$amarco') ";
}
if (($estado!='')&&($estado!="00")){
	$sql=$sql."AND (terminales.ESTADO='$estado') ";
}
if (($tipoterm!='')&&($tipoterm!="00")){
	$sql=$sql."AND (terminales.TIPO LIKE '$tipoterm') ";
	
}
if (($marca!='')&&($marca!="00")){
	$sql=$sql."AND (terminales.MARCA='$marca') ";
}
if (($permisos!='')&&($permisos!="00")){
	switch ($permisos){
		case "NO":
		{
			$sql=$sql."AND (terminales.SEMID='NO') AND (terminales.DUPLEX='NO') ";
			break;
		}
		case "SEMID":
		{
			$sql=$sql."AND (terminales.SEMID='SI') ";
			break;
		}
		case "DUPLEX":
		{
			$sql=$sql."AND (terminales.DUPLEX='SI') ";
			break;
		}
		case "SYD":
		{
			$sql=$sql."AND (terminales.DUPLEX='SI') AND (terminales.SEMID='SI') ";
			break;
		}
	}
}
if (($estado!='')&&($estado!="00")){
	$sql=$sql."AND (terminales.ESTADO='$estado') ";
}
if (($dots!='')&&($dots!="00")){
	$sql=$sql."AND (terminales.DOTS='$dots') ";
}
$sql_no_limit=$sql."ORDER BY flotas.ACRONIMO ASC, terminales.ID ASC";
$sql_limit=$sql_no_limit." LIMIT ".$inicio.",".$tam_pagina.";";
$res=mysql_db_query($base_datos,$sql_no_limit) or die(mysql_error());
$nfilas=mysql_num_rows($res);
$total_pag=ceil($nfilas/$tam_pagina);
############# Enlaces para la exportación #######
$linkpdf = "pdfterminales.php?flota=$flota&tei=$tei&issi=$issi&nserie=$nserie&tipoterm=$tipoterm&marca=$marca&estado=$estado&amarco=$amarco&dots=$dots&permisos=$permisos";
$linkxls = "xlsterminales.php?flota=$flota&tei=$tei&issi=$issi&nserie=$nserie&tipoterm=$tipoterm&marca=$marca&estado=$estado&amarco=$amarco&dots=$dots&permisos=$permisos";
$linkrtf = "rtfterminales.php?flota=$flota&tei=$tei&issi=$issi&nserie=$nserie&tipoterm=$tipoterm&marca=$marca&estado=$estado&amarco=$amarco&dots=$dots&permisos=$permisos";
?>
<h4>Resultado de la búsqueda</h4>
<table>
	<tr class="borde">
		<td class="borde">Nº total de registros: <b><?php echo $nfilas;?></b>.</td>
		<td class="borde">
			Mostrar:
			<select name='tam_pagina' onChange='document.formulario.submit();'>
			<?php
				echo "<option value='30' ";
				if (($tam_pagina=="30") || ($tam_pagina=="")) {
					echo 'selected';
				}
				echo ">30</option>\n";
				echo "<option value='50' ";
				if ($tam_pagina=="50") {
					echo 'selected';
				}
				echo ">50</option>\n";
				echo "<option value='100' ";
				if ($tam_pagina=="100") {
					echo 'selected';
				}
				echo ">100</option>\n";
				echo "<option value='$nfilas' ";
				if ($tam_pagina=="$nfilas") {
					echo 'selected';
				}
				echo ">Todos</option>\n";
			?>
			</select> registros por página
		</td>
		<td class="borde">
		<?php
			if ($total_pag>1){
				echo "Página: \n";
				echo "<select name='pagina' onChange='document.formulario.submit();'>\n";
				for($k=1;$k<=$total_pag;$k++){
					echo "<option value='$k' ";
					if ($pagina==$k) {
						echo 'selected';
					}
					echo ">$k</option>\n";
				}
				echo "</select>\n";
				echo " de $total_pag\n";
			}
		?>
		</td>
<?php
	if ($permiso==2){
?>
		<td class="borde">
			<a href="nuevo_terminal.php"><img src="imagenes/nueva.png" alt="Nuevo Terminal"></a> &mdash; Nuevo Terminal
		</td>
<?php
	}
?>
<?php
	if($nfilas>0){
?>
		<td class="borde">
			<a href="<?php echo $linkpdf;?>"><img src="imagenes/pdf.png" alt="PDF" title="PDF"></a> &mdash;
			<a href="<?php echo $linkxls;?>"><img src="imagenes/xls.png" alt="Excel" title="XLS (Excel)"></a> &mdash;
			<a href="<?php echo $linkrtf;?>"><img src="imagenes/rtf.png" alt="RTF (Word)" title="RTF (Word)"></a>
		</td>
<?php
	}
?>

	</tr>
</table>
</form>
<table>
<?php
if ($nfilas==0){
	echo "<tr><td class='borde'>No hay registros</tr></td>";
}
else {
	if($res2=mysql_db_query($base_datos,$sql_limit)){
		$nfilas2=mysql_num_rows($res2);
		//*TABLA CON RESULTADOS*//
		echo "<tr>\n";
		//* CABECERA  *//
		$campos=array("Detalle","Flota","ISSI","TEI", "Tipo","Marca","Modelo", "Proveedor", "DOTS", "A.M.", "Mnemónico", "Llam. Ind.");
		$ncampos=count($campos);
		for($i=0;$i<$ncampos;$i++){
			echo "<th>";
			echo $campos[$i];
			echo "</th>\n";
		}
		echo "</tr>\n";
		for($i=0;$i<$nfilas2;$i++){
			$fila=mysql_fetch_array($res2);
			echo "<tr";
			if (($i % 2) == 1){
				echo " class='filapar'";
			}
			echo ">\n";
			for($j=0;$j<$ncampos;$j++){
                                $nombre = mysql_field_name($res2, $j);
				if($nombre=="ID"){   //enlace a detalle
					echo "<td class='centro'>";
	                		echo "<a href='detalle_terminal.php?id=$fila[0]'>";
					echo "<img src='imagenes/consulta.png'></a>";
				}
				elseif ($nombre == "TIPO"){
					$tipot = $fila["TIPO"];
					switch ($tipot){
						case ("F"): {
							$tipot = "Fijo";
							break;
						}
						case ("M"): {
							$tipot = "Móvil";
							break;
						}
						case ("MB"): {
							$tipot = "Móvil Básico";
							break;
						}
						case ("MA"): {
							$tipot = "Móvil Avanzado";
							break;
						}
						case ("MG"): {
							$tipot = "Móvil Gateway";
							break;
						}
						case ("P"): {
							$tipot = "Portátil";
							break;
						}
						case ("PB"): {
							$tipot = "Portátil Básico";
							break;
						}
						case ("PA"): {
							$tipot = "Portátil Avanzado";
							break;
						}
						case ("PX"): {
							$tipot = "Portátil ATEX";
							break;
						}
					}
					echo "<td>".$tipot;
				}
				elseif($nombre == "DUPLEX"){
					$duplex = "N";
					if($fila["DUPLEX"]=="SI"){
						$duplex = "D";
						if($fila["SEMID"]=="SI"){
							$duplex = "D + S";
						}
					}
					else {
						if($fila["SEMID"]=="SI"){
							$duplex = "S";
						}
					}
					echo "<td class='centro'>$duplex";
				}			
				else{
					echo "<td>".utf8_encode($fila[$j]);
				}
				echo "</td>\n";
			} //segundo for
			echo "</tr>\n";
		} //primer for
		
	}
	else {
		echo "<b>ERROR:</b> ".mysql_error(); // si hay error en select_limit
	}
}
?>
</table>
</body>
</html>
