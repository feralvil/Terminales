<?php
// ------------ Obtención del usuario Joomla! --------------------------------------- //
// Le decimos que estamos en Joomla
    define( '_JEXEC', 1 );
// Definimos la constante de directorio actual y el separador de directorios (windows server: \ y linux server: /)
    define( 'DS', DIRECTORY_SEPARATOR );
    define('JPATH_BASE', dirname(__FILE__).DS.'..' );

// Cargamos los ficheros de framework de Joomla 1.5, y las definiciones de constantes (IMPORTANTE AMBAS LÍNEAS)
    require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
    require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

// Iniciamos nuestra aplicación (site: frontend)
    $mainframe =& JFactory::getApplication('site');

// Obtenemos los parámetros de Joomla
    $user =& JFactory::getUser();
    $usu = $user->username;
// ------------------------------------------------------------------------------------- //

// ------------ Conexión a BBDD de Terminales ----------------------------------------- //
    include("conexion.php");
    $base_datos=$dbbdatos;
    $link = mysql_connect($dbserv,$dbusu,$dbpaso);
    if(!link){
        echo "<b>ERROR MySQL:</b>".mysql_error();
    }
// ------------------------------------------------------------------------------------- //

    /* GENERACIÓN DEL PDF */
    require_once('tcpdf/config/lang/esp.php');
    require_once('tcpdf/tcpdf.php');

import_request_variables("gp","");

/* Determinamos si es usuario OFICINA COMDES para ver la gestión de flotas */
$sql_oficina="SELECT ID FROM flotas WHERE LOGIN='$usu'";
$res_oficina=mysql_db_query($base_datos,$sql_oficina);
$row_oficina=mysql_fetch_array($res_oficina);
$flota_usu=$row_oficina["ID"];
/*
 *  $permiso = variable de permisos de flota:
 *      0: Sin permiso
 *      1: Permiso de consulta
 *      2: Permiso de modificación
 */
$permiso = 0;
if($flota_usu == 100){
    $permiso = 2;
}
else {
    $sql_permiso = "SELECT * FROM usuarios_flotas WHERE NOMBRE='$usu'";
    $res_permiso = mysql_db_query($base_datos,$sql_permiso) or die(mysql_error());
    $npermiso = mysql_num_rows($res_permiso);
    if ($npermiso > 1){
        $permiso = 1;
    }
}

// Extender la clase TCPDF para crear una cabecera y un pie de página propios
class MYPDF extends TCPDF {
	
	//Cabecera
	public function Header() {
		// Logo
		$this->Image('imagenes/comdes2.png',20);
		// Establecemos la fuente y colores
		$this->SetDrawColor(92, 116, 61);
		$this->SetTextColor(92, 116, 61);
		$this->SetFont('helvetica', 'B', 12);
		// Nos desplazamos a a la derecha
		$this->Cell(20);
		// Título
		$this->Cell(230, 10, 'Detalle de Flota de la RED COMDES', 0, 0, 'C');
		// Logo 2
		$this->Image('imagenes/logo.jpg');
		// Salto de línea
		$this->Ln();
		$this->Cell(0, 0, '', 'T');
		$this->Ln();
	}
	
	// Pie de página
	public function Footer() {
		// Posición at 1.5 cm del fin de página
		$this->SetY(-15);
		// Establecemos la fuente y colores
		$this->SetDrawColor(92, 116, 61);
		$this->SetTextColor(92, 116, 61);
		$this->SetFont('helvetica', 'B', 8);
		// Número de Página
		$this->Cell(0, 10, 'Página '.$this->getAliasNumPage().' de '.$this->getAliasNbPages(), 'T', 0, 'C');
	}
	
	/*
		Función para simplificar la impresión de tablas. Imprime 1 fila de tabla.
		Argumentos:
			- $fila = Fila a imprimir. Incluye datos y/o cabeceras
			- $anchos = Ancho de cada columna (en mm)
			- $campos = Tipo de celda a imprimir:
				- -1 : Celda en Blanco (Celda vacía sin relleno)
				- 0 : Celda de Cabecera (Negrita, con relleno, centrada)
				- 1: Celda de Datos  (Sin negrita, relleno alterno, alineada a la la izquierda)
			- $par = Indica si es una fila par (con relleno gris)
	*/
	public function ImprimeFila($fila, $anchos, $campos, $par) {
		$filas = 1;
		// Comprobamos los anchos
		for ($i=0; $i < count ($anchos); $i++){
			$filas_celda = $this->GetNumLines ($fila[$i], $anchos[$i]);
			if ($filas_celda > $filas) {
				$filas = $filas_celda;
			}
		}
		for ($i=0; $i < count ($anchos); $i++){
			if ($campos[$i]==-1) {
				//$this->Cell($anchos[$i], 5*$filas, '', 0, 'C', 0);
				$fill = 0;
				$borde = 0;
			}
			elseif ($campos[$i]==0) {
				$this->SetFillColor(92, 116, 61);
				$this->SetTextColor(213, 235, 179);
				$this->SetFont('', 'B',10);
				$fill = 1;
				$borde = 1;
				$alin = 'C';
				//$this->Cell($anchos[$i], 5*$filas, $fila[$i], 1, 0, 'C', 1);
			}
			else {
				$fill = 0;
				if ($par){
					$fill = 1;
				}
				$borde = 1;
				$alin = 'L';
				$this->SetFillColor(194, 194, 194);
				$this->SetTextColor(0, 0, 0);
				$this->SetFont('', '',10);
				/*if ($this->GetStringWidth($fila[$i]) > $anchos[$i]) {
					$this->MultiCell($anchos[$i], 5, $fila[$i], 1, 'L', 0, 0, '', '', true, 0);
				}
				else {
					$this->Cell($anchos[$i], 5*$filas, $fila[$i], 1, 0, 'L', $fill);
				}*/
			}
			if ($filas == 1){
				$this->Cell($anchos[$i], 5, $fila[$i], $borde, 0, $alin, $fill);
			}
			else{
				//$this->MultiCell($anchos[$i], 5, $fila[$i], $borde, 'L', 0, 0, '', '', true, 0);
				$this->MultiCell($anchos[$i], 5*$filas, $fila[$i], $borde, $alin, $fill, 0, '', '', true, 0, false, false);
			}
		}
		$this->Ln();
	}
}

// crear nuevo documento
$pdf = new MYPDF('L', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Información de documento
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Oficina COMDES');
$pdf->SetTitle('Flota de la Red COMDES');
$pdf->SetSubject('Flota de la Red COMDES');
$pdf->SetKeywords('COMDES, Flotas');

// Márgenes
$pdf->SetMargins(13.5, PDF_MARGIN_TOP, 13.5);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// Salto automático de página
$pdf->SetAutoPageBreak(TRUE, 15);

// Factor de Escala de las imágenes
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// Cadenas de texto dependientes del Idioma
$pdf->setLanguageArray($l);
// Establecemos la fuente por defecto
$pdf->SetFont('helvetica', '', 8);
// Añadir una página
$pdf->AddPage();

// ---------------------------------------------------------

if ($permiso!=0){
    //datos de la tabla Flotas
    $sql_flota="SELECT * FROM flotas WHERE ID='$id'";
    $res_flota=mysql_db_query($base_datos,$sql_flota) or die ("Error en la consulta de Flota: ".mysql_error());
    $nflota=mysql_num_rows($res_flota);
    if($nflota==0){
        echo "<p class='error'>No hay resultados en la consulta de la Flota</p>\n";
    }
    else{
	$row_flota=mysql_fetch_array($res_flota);
        $usuario = $row_flota["LOGIN"];
    }
    //datos de la tabla Terminales
    // Tipos de termninales
    $tipos = array("%", "F","M%","MB","MA", "MG", "P%", "PB", "PA", "PX");
    $cabecera = array("Total Terminales", "Terminales Fijos","Terminales Móviles","Móviles Básicos","Móviles Avanzados", "Móviles Gateway", "Terminales Portátiles", "Portátiles Básicos", "Portátiles Avanzados", "Portátiles ATEX");
    $nterm = array (0,0,0,0,0,0,0,0,0);
    for($j=0; $j< count($tipos);$j++){
	$sql_term = "SELECT * FROM terminales WHERE FLOTA='$id' AND TIPO LIKE '".$tipos[$j]."'";
	$res_term = mysql_db_query($base_datos,$sql_term) or die ("Error en la consulta de ".$cabecera[$j].": ".mysql_error());
	$nterm[$j+1] = mysql_num_rows($res_term);
    }
    //datos de la tabla Municipio
    // INE
    $ine =$row_flota["INE"];
    $sql_mun = "SELECT * FROM municipios WHERE INE='$ine'";
    $res_mun = mysql_db_query($base_datos,$sql_mun) or die ("Error en la consulta de Municipio".mysql_error());
    $nmun = mysql_num_rows($res_mun);
    if($nmun==0){
        echo "<p class='error'>No hay resultados en la consulta del Municipio</p>\n";
    }
    else{
	$row_mun = mysql_fetch_array($res_mun);
    }
     // Colores y Fuente para los títulos
	$pdf->SetFillColor(92, 116, 61);
	$pdf->SetTextColor(92, 116, 61);
	$pdf->SetDrawColor(92, 116, 61);
	$pdf->SetLineWidth(0.3);
	$pdf->SetFont('', 'B',12);
	$titulo = "Flota ".utf8_encode($row_flota["FLOTA"]). " (".$row_flota["ACRONIMO"].")";
	$pdf->MultiCell(0,5,$titulo,0,'C',0);
	$pdf->Ln(5);
	$pdf->SetFont('','B',10);
	$pdf->Cell(0, 5, 'Datos Administrativos de la Flota',0, 0, 'L', 0);
	$pdf->Ln(5);
	$fila_imp = array('ID', 'Nombre', 'Acrónimo', 'Usuario', 'Activa', 'Encriptación');
	$anchos_imp = array(20, 100, 40, 40, 30, 40);
	$campos_imp = array(0,0,0,0,0,0,0);
	$pdf->ImprimeFila ($fila_imp, $anchos_imp, $campos_imp, false);
	$fila_imp = array($row_flota["ID"], utf8_encode($row_flota["FLOTA"]), $row_flota["ACRONIMO"], $row_flota["LOGIN"], $row_flota["ACTIVO"], $row_flota["ENCRIPTACION"]);
	$campos_imp = array(1,1,1,1,1,1);
	$pdf->ImprimeFila ($fila_imp, $anchos_imp, $campos_imp, false);
	$pdf->Ln(5);
	$pdf->SetFont('','B',10);
	$pdf->Cell(0, 5, 'Datos de Localización de la Flota',0, 0, 'L', 0);
	$pdf->Ln(5);
	$fila_imp = array('Domicilio', 'C.P.', 'Ciudad', 'Provincia');
	$anchos_imp = array(100, 20, 100, 50);
	$campos_imp = array(0,0,0,0);
	$pdf->ImprimeFila ($fila_imp, $anchos_imp, $campos_imp, false);
	$fila_imp = array(utf8_encode($row_flota["DOMICILIO"]), $row_flota["CP"], utf8_encode($row_mun["MUNICIPIO"]), utf8_encode($row_mun["PROVINCIA"]));
	$campos_imp = array(1,1,1,1);
	$pdf->ImprimeFila ($fila_imp, $anchos_imp, $campos_imp, false);
	$pdf->Ln(5);

	// Datos de Contactos
	// Consulta a la base de Datos de contacto
	$pdf->SetTextColor(92, 116, 61);
	$pdf->SetFont('','B',10);
	$pdf->Cell(0, 5, 'Contactos de la Flota Usuaria',0, 0, 'L', 0);
	$pdf->Ln();
	if (($row_flota["RESPONSABLE"]=="0")&&($row_flota["CONTACTO1"]=="0")&&($row_flota["CONTACTO2"]=="0")&&($row_flota["CONTACTO3"]=="0")){
		$pdf->SetTextColor(255, 0, 0);
		$pdf->SetFont('', 'B',10);
		$pdf->Cell(0,5,'No hay contactos para la Flota',0,'L',0);
		$pdf->Ln();
	}
	else{
		$fila_imp = array('', 'Nombre', 'Cargo', 'Teléfono', 'Móvil', 'Correo Electrónico');
		$anchos_imp = array(30, 90, 55, 25, 25, 45);
		$campos_imp = array(-1, 0, 0, 0, 0);
		$pdf->ImprimeFila ($fila_imp, $anchos_imp, $campos_imp, false);
		$relleno = false;
		$idc = array ($row_flota["RESPONSABLE"], $row_flota["CONTACTO1"], $row_flota["CONTACTO2"], $row_flota["CONTACTO3"]);
		$idcampo = array ("Responsable", "Contacto 1", "Contacto 2", "Contacto 3");
		for ($j = 0; $j < count($idc); $j++){
			if ($idc[$j]!=0){
				$id_contacto = $idc[$j];
				$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
				$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
				$ncontacto=mysql_num_rows($res_contacto);
				if($ncontacto!=0){
					$row_contacto=mysql_fetch_array($res_contacto);
					$nombre = utf8_encode($row_contacto["NOMBRE"]);
					$cargo = utf8_encode($row_contacto["CARGO"]);
					$fila_imp = array($idcampo[$j], $nombre, $cargo, $row_contacto["TELEFONO"], $row_contacto["MOVIL"], $row_contacto["MAIL"]);
					$campos_imp = array(0, 1, 1, 1, 1);
					$pdf->ImprimeFila ($fila_imp, $anchos_imp, $campos_imp, $relleno);
					$relleno = !$relleno;
				}
				else {
					$pdf->SetTextColor(255, 0, 0);
					$pdf->SetFont('', 'B',10);
					$pdf->Cell(0,5,"No hay resulta en la consultados del $idcampo[$j]",0,'L',$relleno);
				}
			}
		}
	}
	$pdf->Ln(5);

	// Datos de Terminales
	$pdf->SetTextColor(92, 116, 61);
	$pdf->SetFont('','B',10);
	$pdf->Cell(0, 5, 'Resumen de Terminales de la Flota',0, 0, 'L', 0);
	$pdf->Ln();
	$anchos_imp = array(27, 27, 27, 27, 27, 27, 27, 27, 27, 27);
	$campos_imp = array(0,0,0,0,0,0,0,0,0,0);
	$pdf->ImprimeFila ($cabecera, $anchos_imp, $campos_imp, false);
	$campos_imp = array(1,1,1,1,1,1,1,1,1,1);
        $pdf->ImprimeFila ($nterm, $anchos_imp, $campos_imp, false);
	$pdf->Ln(5);

        if (($permiso==1)||(($permiso==2)&&($id!=100))){
            // Datos de Acceso a Flotas
            $pdf->SetTextColor(92, 116, 61);
            $pdf->SetFont('','B',10);
            $pdf->Cell(0, 5, 'Flotas a las que tiene acceso',0, 0, 'L', 0);
            $pdf->Ln();
            $sql_flotas = "SELECT ID, ACRONIMO, FLOTA FROM flotas, usuarios_flotas WHERE ";
            $sql_flotas = $sql_flotas."usuarios_flotas.NOMBRE='$usuario' AND flotas.ID = usuarios_flotas.ID_FLOTA";
            $res_flotas=mysql_db_query($base_datos,$sql_flotas) or die(mysql_error());
            $nflotas=mysql_num_rows($res_flotas);
            $fila_imp = array ("ID", "Acrónimo", "Flota", "", "ID", "Acrónimo", "Flota");
            $anchos_imp = array (10, 30, 90, 10, 10, 30, 90);
            $campos_imp = array(0, 0, 0, -1, 0, 0, 0);
            $pdf->ImprimeFila ($fila_imp, $anchos_imp, $campos_imp, false);
            $filas = floor($nflotas / 2);
            $relleno = false;
            if (($nflotas % 2)==1){
                $filas += 1;
            }
            for ($i = 0; $i < $filas; $i++){
                $fila_imp = array ("", "", "", "", "", "", "");
                for ($j = 0; $j < 2; $j++){
                    $row_flotas = mysql_fetch_array($res_flotas);
                    $fila_imp[3*$j+$j] = $row_flotas["ID"];
                    $fila_imp[3*$j+$j+1] = $row_flotas["ACRONIMO"];
                    $fila_imp[3*$j+$j+2] = utf8_encode($row_flotas["FLOTA"]);
                }
                $campos_imp = array(1, 1, 1, -1, 1, 1, 1);
                $pdf->ImprimeFila ($fila_imp, $anchos_imp, $campos_imp, $relleno);
                $relleno = !$relleno;
            }
        }

}
else {
	$error = "Acceso denegado. No le está permitido el acceso a los datos de esta Flota, pues pertenece a otra flota.";
	$pdf->SetTextColor(255, 0, 0);
	$pdf->SetFont('', 'B',10);
	$pdf->MultiCell(0,5,$error,0,'L',0);
	
}

// Generar y enviar el documento PDF
$pdf->Output("Flota_COMDES-$id.pdf", 'I');
?>
