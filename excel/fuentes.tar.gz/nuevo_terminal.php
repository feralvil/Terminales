<?php
// ------------ Obtención del usuario Joomla! --------------------------------------- //
        // Le decimos que estamos en Joomla
        define( '_JEXEC', 1 );

	// Definimos la constante de directorio actual y el separador de directorios (windows server: \ y linux server: /)
	define( 'DS', DIRECTORY_SEPARATOR );
	define('JPATH_BASE', dirname(__FILE__).DS.'..' );

	// Cargamos los ficheros de framework de Joomla 1.5, y las definiciones de constantes (IMPORTANTE AMBAS LÍNEAS)
	require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

	// Iniciamos nuestra aplicación (site: frontend)
	$mainframe =& JFactory::getApplication('site');

	// Obtenemos los parámetros de Joomla
	$user =& JFactory::getUser();
	$usu = $user->username;
// ------------------------------------------------------------------------------------- //

// ------------ Conexión a BBDD de Terminales ----------------------------------------- //
        include("conexion.php");
        $base_datos=$dbbdatos;
        $link=mysql_connect($dbserv,$dbusu,$dbpaso);
        if(!link){
            echo "<b>ERROR MySQL:</b>".mysql_error();
        }
// ------------------------------------------------------------------------------------- //

import_request_variables("gp","");

/* Determinamos si es usuario OFICINA COMDES para ver la gestión de flotas */
$sql_oficina="SELECT ID FROM flotas WHERE LOGIN='$usu'";
$res_oficina=mysql_db_query($base_datos,$sql_oficina);
$row_oficina=mysql_fetch_array($res_oficina);
$flota_usu=$row_oficina["ID"];
/*
 *  $permiso = variable de permisos de flota:
 *      0: Sin permiso
 *      1: Permiso de consulta
 *      2: Permiso de modificación
 */
$permiso=0;
if($flota_usu==100){
    $permiso = 2;
}

$txt_flota = "";
if($id!=""){
	$sql_flota="SELECT * FROM flotas WHERE ID='$id'";
	$res_flota=mysql_db_query($base_datos,$sql_flota);
	$row_flota=mysql_fetch_array($res_flota);
	$id_flota=$row_flota["ID"];
	$txt_flota = " de la Flota ".utf8_encode($row_flota["FLOTA"])." (".$row_flota["ACRONIMO"].")";
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Detalle del Terminal COMDES</title>
 <link rel="StyleSheet" type="text/css" href="estilo.css">
</head>
<body>
<?php
	if($permiso==2){
?>
<h1>Nuevo Terminal<?php echo $txt_flota;?></h1>
<form action="update_terminal.php" method="POST" name="formterminal">
<h2>Datos Administrativos del Terminal</h2>
	<table>
		<TR>
			<TH class="t6c">Tipo de Equipo</TH>
			<TH class="t6c">Marca</TH>
			<TH class="t6c">Modelo</TH>
			<TH class="t6c">Proveedor</TH>
			<TH class="t6c">Acuerdo Marco</TH>
			<TH class="t6c">Alta en el DOTS</TH>
		</TR>
		<TR>
			<TD class="centro">
				<select name="tipo">
					<option value="00" <?php if (($tipo=="00")||($tipo=="")) echo 'selected'; ?>>Tipo de Terminal</option>
					<option value="F">Fijo</option>
					<option value="M">Móvil</option>
					<option value="MB">- Móvil Básico</option>
					<option value="MA">- Móvil Avanzado</option>
					<option value="MG">- Móvil Gateway/ Repeater</option>
					<option value="P">Portátil</option>
					<option value="PB">- Portátil Básico</option>
					<option value="PA">- Portátil Avanzado</option>
					<option value="PX">- Portátil ATEX</option>
				</select>
			</TD>
			<TD class="centro">
				<input type="text" name="marca" size="20" value="">
			</TD>
			<TD class="centro">
				<input type="text" name="modelo" size="20" value="">
			</TD>
			<TD class="centro">
				<input type="text" name="proveedor" size="20" value="">
			</TD>
			<TD class="centro">
				<select name="am" onChange="document.formulario.submit();">
					<option value="SI">SI</option>
					<option value="NO">NO</option>
				</select>
			</TD>
			<TD class="dots">
				<select name="am" onChange="document.formulario.submit();">
					<option value="SI">SI</option>
					<option value="NO">NO</option>
				</select>
			</TD>
		</TR>
	</table>
<h2>Datos de la Flota</h2>
	<table>
		<TR>
			<TH>Flota Usuaria del Terminal</TH>
			<TD>
				<select name="flota">
				<?php
					$sql_flotas = "SELECT * from flotas";
					$res_flotas=mysql_db_query($base_datos,$sql_flotas) or die ("Error en la consulta de Flotas usuarias: ".mysql_error());
					$nflotas=mysql_num_rows($res_flotas);
					for ($j=1;$j<=$nflotas;$j++){
						$row_flotas=mysql_fetch_array($res_flotas);
				?>
					<option value="<?php echo $row_flotas["ID"];?>" <?php if($id_flota=="$j") echo 'selected';?>><?php echo utf8_encode($row_flotas["FLOTA"]);?></option>
				<?php
					}
				?>
				</select>
			</TD>
		</TR>
	</table>
<h2>Datos Técnicos del Terminal</h2>
	<table>
            <TR class="filapar">
			<TH class="t4c">ISSI</TH>
			<TD>
				<input type="text" name="issi" size="20" value="">
			</TD>
			<TH class="t4c">TEI</TH>
			<TD>
				<input type="text" name="tei" size="20" value="">
			</TD>
		</TR>
		<TR>
			<TH class="t4c">Código Hardware</TH>
			<TD>
				<input type="text" name="codigohw" size="20" value="">
			</TD>
			<TH class="t4c">Número de Serie</TH>
			<TD>
				<input type="text" name="nserie" size="20" value="">
			</TD>
		</TR>
		<TR class="filapar">
			
			<TH class="t4c">Mnemónico</TH>
			<TD>
				<input type="text" name="mnemonico" size="20" value="">
			</TD>
			<TH class="t4c">Estado</TH>
			<TD>
				<select name="estado">
					<option value="A">Alta</option>
					<option value="B">Baja</option>
				</select>
			</TD>
		</TR>
		<TR>
			<TH class="t4c">Llamada Semi-Dúplex</TH>
			<TD>
				<select name="semid">
					<option value="SI">Sí</option>
					<option value="NO">No</option>
				</select>
			</TD>
			<TH class="t4c">Llamada Dúplex</TH>
			<TD>
				<select name="duplex">
					<option value="SI">Sí</option>
					<option value="NO">No</option>
				</select>
			</TD>
		</TR>
		<TR class="filapar">
			<TH class="t4c">Nº K</TH>
			<TD><input type="text" name="numerok" size="20" value="<?php echo $row_terminal["NUMEROK"];?>"></TD>
			<TH class="t4c">Carpeta</TH>
			<TD><input type="text" name="carpeta" size="20" value="<?php echo $row_terminal["CARPETA"];?>"></TD>
		</TR>
		<TR>
			<TH class="t4c">Observaciones</TH>
			<TD colspan='3'>
				<input type="text" name="observaciones" size="40" value="<?php echo utf8_encode($row_terminal["OBSERVACIONES"]);?>">
			</TD>
		</TR>
	</table>
	<input type="hidden" name="origen" value="nuevo">
	<table>
		<tr>
			<TD class="borde">
				<input type='image' name='action' src='imagenes/guardar.png' alt='Guardar' title="Guardar"><br>Guardar Terminal
			</TD>
			<TD class="borde">
				<a href='#' onclick='document.formterminal.reset();'>
					<img src='imagenes/no.png' alt='Borrar' title="Cancelar Cambios">
				</a><br>Cancelar Cambios
			</TD>
		</tr>
	</table>
</form>
<?php
	}
	else{
?>
	<h1>Acceso denegado</h1>
	<p class='error'>No le está permitido añadir un nuevo terminal.</p>
<?php
	}
?>
</body>
</html>
