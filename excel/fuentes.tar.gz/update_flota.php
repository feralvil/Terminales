<?php
// ------------ Obtención del usuario Joomla! --------------------------------------- //
        // Le decimos que estamos en Joomla
        define( '_JEXEC', 1 );

	// Definimos la constante de directorio actual y el separador de directorios (windows server: \ y linux server: /)
	define( 'DS', DIRECTORY_SEPARATOR );
	define('JPATH_BASE', dirname(__FILE__).DS.'..' );

	// Cargamos los ficheros de framework de Joomla 1.5, y las definiciones de constantes (IMPORTANTE AMBAS LÍNEAS)
	require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

	// Iniciamos nuestra aplicación (site: frontend)
	$mainframe =& JFactory::getApplication('site');

	// Obtenemos los parámetros de Joomla
	$user =& JFactory::getUser();
	$usu = $user->username;
// ------------------------------------------------------------------------------------- //

// ------------ Conexión a BBDD de Terminales ----------------------------------------- //
        include("conexion.php");
        $base_datos=$dbbdatos;
        $link=mysql_connect($dbserv,$dbusu,$dbpaso);
        if(!link){
            echo "<b>ERROR MySQL:</b>".mysql_error();
        }
// ------------------------------------------------------------------------------------- //

import_request_variables("gp","");

/* Determinamos si es usuario OFICINA COMDES para ver la gestión de flotas */
$sql_oficina="SELECT ID FROM flotas WHERE LOGIN='$usu'";
$res_oficina=mysql_db_query($base_datos,$sql_oficina);
$row_oficina=mysql_fetch_array($res_oficina);
$flota_usu=$row_oficina["ID"];
/*
 *  $permiso = variable de permisos de flota:
 *      0: Sin permiso
 *      1: Permiso de consulta
 *      2: Permiso de modificación
 */
$permiso=0;
if($flota_usu==100){
    $permiso = 2;
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Actualización del Terminal COMDES</title>
 <link rel="StyleSheet" type="text/css" href="estilo.css">
</head>
<body>
<?php
	if($permiso==2){
		$enlace = "detalle_flota.php?id=$idflota";
		$repetido = false;
		if($origen=="editar"){
			$titulo = "Actualizar los datos de la Flota $flota_org ($acro_org)";
			$flota = utf8_decode($flota);
			$domicilio = utf8_decode($domicilio);
			$sql_update = "UPDATE flotas SET FLOTA='$flota', ACRONIMO='$acronimo', DOMICILIO='$domicilio', ";
			$sql_update = $sql_update."CP='$cp', INE='$ine', ENCRIPTACION='$encriptacion' WHERE ID=$idflota";
			$mensaje = "Los datos se han modificado correctamente.";
			$error = "Error al modificar los datos:";
		}
		if($origen=="baja"){
			$titulo = "Desactivar la Flota $flota_org ($acro_org)";
			$error = "Error al desactivar la Flota:";
			$mensaje = "Flota desactivada correctamente.";
			$sql_update = "UPDATE flotas SET ACTIVO='NO' WHERE ID=$idflota";
		}
		if($origen=="alta"){
			$titulo = "Activar la Flota $flota_org ($acro_org)";
                        $error = "Error al activar la Flota:";
                        $mensaje = "Flota activada correctamente.";
                        $sql_update = "UPDATE flotas SET ACTIVO='SI' WHERE ID=$idflota";
		}
		if($origen=="nueva"){
			$i = 0;
			$titulo = "Nueva Flota $flota ($acronimo)";
			$sql_flotas="SELECT * FROM flotas";
			$res_flotas=mysql_db_query($base_datos,$sql_flotas) or die ("Error en la consulta de Flota: ".mysql_error());
			$nflotas=mysql_num_rows($res_flotas);
			$error = "Error al guardar la flota $flota:";
			if (($usuario=="")||($flota=="")||($acronimo=="")){
				if ($usuario==""){
					$vacio = "USUARIO";
				}
				if ($flota==""){
					if ($usuario==""){
						$vacio = $vacio.", FLOTA";
					}
					else {
						$vacio = "FLOTA";
					}
				}
				if ($acronimo==""){
					if (($usuario=="")||($flota=="")){
						$vacio = $vacio.", ACRÓNIMO";
					}
					else {
						$vacio = "ACRÓNIMO";
					}
				}
				$repetido = true;
				$error = "Error: Campo(s) $vacio vacío(s)";
			}
			while (($i < $nflotas)&&(!$repetido)){
				$row_flota=mysql_fetch_array($res_flotas);
				$i++;
				if ($flota == utf8_encode($row_flota["FLOTA"])){
					$repetido = true;
					$error = "<b>Error</b>: La flota $flota ya existe";
				}
				elseif ($acronimo == $row_flota["ACRONIMO"]){
					$repetido = true;
					$error = "<b>Error</b>: El acrónimo $acronimo ya se emplea para la flota ".$row_flota["FLOTA"].".<br>Vuelva atrás y elija otro";
				}
				elseif ($usuario == $row_flota["LOGIN"]){
					$repetido = true;
					$error = "<b>Error</b>: El usuario $usuario ya se emplea para la flota ".$row_flota["FLOTA"].".<br>Vuelva atrás y elija otro";
				}
			}
			$flota = utf8_decode($flota);
                        $domicilio = utf8_decode($domicilio);
			$flota_txt = utf8_encode($flota);
			$acronimo = utf8_decode($acronimo);
			$sql_update = "INSERT INTO flotas (ID, FLOTA, ACRONIMO, INE, DOMICILIO, CP, RESPONSABLE, CONTACTO1, CONTACTO2, CONTACTO3, LOGIN, ACTIVO, ";
			$sql_update = $sql_update."ENCRIPTACION) VALUES ($idflota, '$flota', '$acronimo', '$ine', '$domicilio', '$ine', '0', '0', '0', '0', ";
			$sql_update = $sql_update."'$usuario', '$activa', '$encriptacion')";
			$mensaje = "Flota $flota_txt guardada correctamente.";
		}
		if ($repetido){
			$res_update=false;
			$enlace = "#\" onclick=\"history.go(-1);\"";
		}
		else{
                    if ($origen=="nueva"){
                        $sql_perm = "INSERT INTO usuarios_flotas (NOMBRE, ID_FLOTA) VALUES ('$usuario', '$idflota')";
                        $res_perm = mysql_db_query($base_datos, $sql_perm);
                        if ($res_perm){
                            $res_update = mysql_db_query($base_datos, $sql_update);
                        }
                        else{
                            $error = "Error al añadir los permisos";
                            $res_update = false;
                        }
                    }
                    else{
                        $res_update=mysql_db_query($base_datos,$sql_update);
                    }

		}
?>
<h1><?php echo $titulo;?></h1>
	<div class="centro">
<?php
		if ($res_update){
?>
			<p><img src='imagenes/clean.png' alt='OK'></p>
			<p><?php echo $mensaje;?></p>
			<p><a href="<?php echo $enlace;?>"><img src='imagenes/atras.png' alt='Volver' title="Volver"></a><BR>Volver</p>
<?php
		}
		else {
?>
			<p><img src='imagenes/error.png' alt='Error'></p>
			<p class="error"><?php echo $error;?> <?php echo mysql_error();?></p>
			<p><a href="<?php echo $enlace;?>"><img src='imagenes/atras.png' alt='Volver' title="Volver"></a><BR>Volver</p>
<?php
		}
?>
	</div>
<?php
	}
	else{
?>
	<h1>Acceso denegado</h1>
	<p class='error'>No le está permitido modificar los datos de la flota.</p>
<?php
	}
?>
</body>
</html>
