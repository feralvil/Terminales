<?php
// ------------ Obtención del usuario Joomla! --------------------------------------- //
        // Le decimos que estamos en Joomla
        define( '_JEXEC', 1 );

	// Definimos la constante de directorio actual y el separador de directorios (windows server: \ y linux server: /)
	define( 'DS', DIRECTORY_SEPARATOR );
	define('JPATH_BASE', dirname(__FILE__).DS.'..' );

	// Cargamos los ficheros de framework de Joomla 1.5, y las definiciones de constantes (IMPORTANTE AMBAS LÍNEAS)
	require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

	// Iniciamos nuestra aplicación (site: frontend)
	$mainframe =& JFactory::getApplication('site');

	// Obtenemos los parámetros de Joomla
	$user =& JFactory::getUser();
	$usu = $user->username;
// ------------------------------------------------------------------------------------- //

// ------------ Conexión a BBDD de Terminales ----------------------------------------- //
        include("conexion.php");
        $base_datos=$dbbdatos;
        $link=mysql_connect($dbserv,$dbusu,$dbpaso);
        if(!link){
            echo "<b>ERROR MySQL:</b>".mysql_error();
        }
// ------------------------------------------------------------------------------------- //

import_request_variables("gp","");

/* Determinamos si es usuario OFICINA COMDES para ver la gestión de flotas */
$sql_oficina="SELECT ID FROM flotas WHERE LOGIN='$usu'";
$res_oficina=mysql_db_query($base_datos,$sql_oficina);
$row_oficina=mysql_fetch_array($res_oficina);
$flota_usu=$row_oficina["ID"];
/*
 *  $permiso = variable de permisos de flota:
 *      0: Sin permiso
 *      1: Permiso de consulta
 *      2: Permiso de modificación
 */
$permiso=0;
if($flota_usu==100){
    $permiso = 2;
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Editar Terminal COMDES</title>
 <link rel="StyleSheet" type="text/css" href="estilo.css">
</head>
<?php
	//datos de la tabla terminales
	$sql_terminal="SELECT * FROM terminales WHERE ID='$id'";
	$res_terminal=mysql_db_query($base_datos,$sql_terminal) or die ("Error en la consulta de terminal: ".mysql_error());
	$nterminal=mysql_num_rows($res_terminal);
	if($nterminal==0){
		echo "<p class='error'>No hay resultados en la consulta del Terminal</p>\n";
	}
	else{
		$row_terminal=mysql_fetch_array($res_terminal);
		$id_flota = $row_terminal["FLOTA"];
	}
	//datos de la tabla flotas
	$sql_flota="SELECT * FROM flotas WHERE ID='$id_flota'";
	$res_flota=mysql_db_query($base_datos,$sql_flota) or die ("Error en la consulta de Flota Usuaria: ".mysql_error());
	$nflota=mysql_num_rows($res_flota);
	if($nflota==0){
		echo "<p class='error'>No hay resultados en la consulta de la Flota</p>\n";
	}
	else{
		$row_flota=mysql_fetch_array($res_flota);
	}
	//datos de la tabla municipios
	$ine = $row_flota ["INE"];
	$sql_mun = "SELECT * FROM municipios WHERE INE='$ine'";
	$res_mun = mysql_db_query($base_datos,$sql_mun) or die ("Error en la consulta de Municipio".mysql_error());
	$nmun = mysql_num_rows($res_mun);
	if($nmun==0){
		echo "<p class='error'>No hay resultados en la consulta del Municipio</p>\n";
	}
	else{
		$row_mun = mysql_fetch_array($res_mun);
	}

	############# Enlaces para la exportación #######
	$linkpdf = "pdfterminal.php?id=$id";
	$linkxls = "xlsterminal.php?id=$id";
	$linkrtf = "rtfterminal.php?id=$id";
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Editar Terminal COMDES</title>
 <link rel="StyleSheet" type="text/css" href="estilo.css">
</head>
<?php
	//datos de la tabla terminales
	$sql_terminal="SELECT * FROM terminales WHERE ID='$id'";
	$res_terminal=mysql_db_query($base_datos,$sql_terminal) or die ("Error en la consulta de terminal: ".mysql_error());
	$nterminal=mysql_num_rows($res_terminal);
	if($nterminal==0){
		echo "<p class='error'>No hay resultados en la consulta del Terminal</p>\n";
	}
	else{
		$row_terminal=mysql_fetch_array($res_terminal);
		$id_flota = $row_terminal["FLOTA"];
		$tipo = $row_terminal["TIPO"];
		$am = $row_terminal["AM"];
		$dots = $row_terminal["DOTS"];
	}
	//datos de la tabla flotas
	$sql_flota="SELECT * FROM flotas WHERE ID='$id_flota'";
	$res_flota=mysql_db_query($base_datos,$sql_flota) or die ("Error en la consulta de terminal: ".mysql_error());
	$nflota=mysql_num_rows($res_flota);
	if($nflota==0){
		echo "<p class='error'>No hay resultados en la consulta de la Flota</p>\n";
	}
	else{
		$row_flota=mysql_fetch_array($res_flota);
	}
	//datos de la tabla municipios
	$ine = $row_flota ["INE"];
	$sql_mun = "SELECT * FROM municipios WHERE INE='$ine'";
	$res_mun = mysql_db_query($base_datos,$sql_mun) or die ("Error en la consulta de Municipio".mysql_error());
	$nmun = mysql_num_rows($res_mun);
	if($nmun==0){
		echo "<p class='error'>No hay resultados en la consulta del Municipio</p>\n";
	}
	else{
		$row_mun = mysql_fetch_array($res_mun);
	}
?>
<body>
<?php
	if($permiso==2){
?>
<h1>Editar Terminal TEI: <?php echo $row_terminal["TEI"];?> / ISSI: <?php echo $row_terminal["ISSI"];?></h1>
<form action="update_terminal.php" method="POST" name="formterminal">
<h2>Datos Administrativos del Terminal</h2>
	<table>
		<TR>
			<TH class="t6c">Tipo de Equipo</TH>
			<TH class="t6c">Marca</TH>
			<TH class="t6c">Modelo</TH>
			<TH class="t6c">Proveedor</TH>
			<TH class="t6c">Acuerdo Marco</TH>
			<TH class="t6c">Alta en el DOTS</TH>
		</TR>
		<TR>
			<TD class="centro">
				<select name="tipo">
					<option value="00" <?php if (($tipo=="00")||($tipo=="")) echo 'selected'; ?>>Tipo de Terminal</option>
					<option value="F" <?php if ($tipo=="F") echo 'selected'; ?>>Fijo</option>
					<option value="M" <?php if ($tipo=="M") echo 'selected'; ?>>Móvil</option>
					<option value="MB" <?php if ($tipo=="MB") echo 'selected'; ?>>- Móvil Básico</option>
					<option value="MA" <?php if ($tipo=="MA") echo 'selected'; ?>>- Móvil Avanzado</option>
					<option value="MG" <?php if ($tipo=="MG") echo 'selected'; ?>>- Móvil Gateway/ Repeater</option>
					<option value="P" <?php if ($tipo=="P") echo 'selected'; ?>>Portátil</option>
					<option value="PB" <?php if ($tipo=="PB") echo 'selected'; ?>>- Portátil Básico</option>
					<option value="PA" <?php if ($tipo=="PA") echo 'selected'; ?>>- Portátil Avanzado</option>
					<option value="PX" <?php if ($tipo=="PX") echo 'selected'; ?>>- Portátil ATEX</option>
				</select>
			</TD>
			<TD class="centro">
				<input type="text" name="marca" size="20" value="<?php echo $row_terminal["MARCA"];?>">
			</TD>
			<TD class="centro">
				<input type="text" name="modelo" size="20" value="<?php echo $row_terminal["MODELO"];?>">
			</TD>
			<TD class="centro">
				<input type="text" name="proveedor" size="20" value="<?php echo $row_terminal["PROVEEDOR"];?>">
			</TD>
			<TD class="centro">
				<select name="am" onChange="document.formulario.submit();">
					<option value="SI" <?php if ($am=="SI") echo 'selected'; ?>>SI</option>
					<option value="NO" <?php if ($am=="NO") echo 'selected'; ?>>NO</option>
				</select>
			</TD>
			<TD class="centro">
				<select name="dots" onChange="document.formulario.submit();">
					<option value="SI" <?php if ($dots=="SI") echo 'selected'; ?>>SI</option>
					<option value="NO" <?php if ($dots=="NO") echo 'selected'; ?>>NO</option>
				</select>
			</TD>
		</TR>
	</table>
<h2>Datos de la Flota</h2>
	<table>
		<TR>
			<TH class="t40p">Nombre</TH>
			<TH class="t10c">Acrónimo</TH>
			<TH class="t40p">Localización</TH>
			<TH class="t10c">Ir a Flota</TH>
		</TR>
		<TR>
			<TD><?php echo utf8_encode($row_flota["FLOTA"]);?></TD>
			<TD><?php echo $row_flota["ACRONIMO"];?></TD>
			<TD><?php echo utf8_encode($row_flota["DOMICILIO"])." &mdash; ".$row_flota["CP"]." ".utf8_encode($row_mun["MUNICIPIO"]);?></TD>
			<TD class="centro"><a href="detalle_flota.php?id=<?php echo $row_flota["ID"];?>"><img src="imagenes/ir.png" alt="Ir"></a></TD>
		</TR>
	</table>
<h3>Contactos de la Flota Usuaria</h3>
<?php
	if (($row_flota["RESPONSABLE"]=="0")&&($row_flota["CONTACTO1"]=="0")&&($row_flota["CONTACTO2"]=="0")&&($row_flota["CONTACTO3"]=="0")){
?>
		<p class='error'>No hay Contactos para la flota</p>
<?php
	}
	else{
?>
	<table>
		<TR>
			<TD class="t10c">&nbsp;</TD>
			<TH class="t4c">Nombre</TH>
			<TH class="t4c">Cargo</TH>
			<TH class="t10c">Teléfono</TH>
			<TH class="t10c">Móvil</TH>
			<TH class="t5c">Correo Electrónico</TH>
		</TR>

<?php
		$par = 0;
		// Datos de contactos
		$id_contacto = $row_flota["RESPONSABLE"];
		$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
		$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
		$ncontacto=mysql_num_rows($res_contacto);
		if($ncontacto!=0){
			$row_contacto=mysql_fetch_array($res_contacto);
?>
		<TR>
			<TH>Responsable</TH>
			<TD><?php echo utf8_encode($row_contacto["NOMBRE"]);?></TD>
			<TD><?php echo utf8_encode($row_contacto["CARGO"]);?></TD>
			<TD><?php echo utf8_encode($row_contacto["TELEFONO"]);?></TD>
			<TD><?php echo utf8_encode($row_contacto["MOVIL"]);?></TD>
			<TD><?php echo utf8_encode($row_contacto["MAIL"]);?></TD>
		</TR>
	<?php
			$par++;
		
		}
		if ($row_flota["CONTACTO1"]!="0"){
			$id_contacto = $row_flota["CONTACTO1"];
			$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
			$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
			$ncontacto=mysql_num_rows($res_contacto);
			if($ncontacto==0){
				echo "<p class='error'>No hay resultados en la consulta del Contacto 1</p>\n";
			}
			else{
				$row_contacto=mysql_fetch_array($res_contacto);
			}
	?>
			<TR <?php if (($par % 2)==1) echo "class='filapar'";?>>
				<TH>Contacto 1</TH>
				<TD><?php echo utf8_encode($row_contacto["NOMBRE"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["CARGO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["TELEFONO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MOVIL"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MAIL"]);?></TD>
			</TR>
	<?php
			$par++;
		}
		if ($row_flota["CONTACTO2"]!="0"){
			$id_contacto = $row_flota["CONTACTO2"];
			$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
			$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
			$ncontacto=mysql_num_rows($res_contacto);
			if($ncontacto==0){
				echo "<p class='error'>No hay resultados en la consulta del Contacto 2</p>\n";
			}
			else{
				$row_contacto=mysql_fetch_array($res_contacto);
			}
	?>
			<TR <?php if (($par % 2)==1) echo "class='filapar'";?>>
				<TH>Contacto 2</TH>
				<TD><?php echo utf8_encode($row_contacto["NOMBRE"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["CARGO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["TELEFONO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MOVIL"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MAIL"]);?></TD>
			</TR>
	<?php
			$par++;
		}
		if ($row_flota["CONTACTO3"]!="0"){
			$id_contacto = $row_flota["CONTACTO3"];
			$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
			$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
			$ncontacto=mysql_num_rows($res_contacto);
			if($ncontacto==0){
				echo "<p class='error'>No hay resultados en la consulta del Contacto 3</p>\n";
			}
			else{
				$row_contacto=mysql_fetch_array($res_contacto);
			}
	?>
			<TR <?php if (($par % 2)==1) echo "class='filapar'";?>>
				<TH>Contacto 3</TH>
				<TD><?php echo utf8_encode($row_contacto["NOMBRE"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["CARGO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["TELEFONO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MOVIL"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MAIL"]);?></TD>
			</TR>
	<?php
		}
	?>
	</table>
<?php
	}
?>
<h2>Datos Técnicos del Terminal</h2>
	<table>
            <TR class="filapar">
			<TH class="t4c">ISSI</TH>
			<TD><?php echo $row_terminal["ISSI"];?></TD>
			<TH class="t4c">TEI</TH>
			<TD><?php echo $row_terminal["TEI"];?></TD>
		</TR>
                <TR>
			<TH class="t4c">Código Hardware</TH>
			<TD><?php echo $row_terminal["CODIGOHW"];?></TD>
			<TH class="t4c">Número de Serie</TH>
			<TD><?php echo $row_terminal["NSERIE"];?></TD>
		</TR>
		<TR class="filapar">
			<TH class="t4c">ID</TH>
			<TD><?php echo $row_terminal["ID"];?></TD>
			<TH class="t4c">Mnemónico</TH>
			<TD><input type="text" name="mnemonico" size="20" value="<?php echo $row_terminal["MNEMONICO"];?>"></TD>
		</TR>
		<TR>
			<TH class="t4c">Llamada Semi-Dúplex</TH>
			<TD>
				<select name="semid">
					<option value="SI" <?php if ($row_terminal["SEMID"]=="SI") echo " 'selected'";?>>SI</option>
					<option value="NO" <?php if ($row_terminal["SEMID"]=="NO") echo " 'selected'";?>>NO</option>
				</select>
			</TD>
			<TH class="t4c">Llamada Dúplex</TH>
			<TD>
				<select name="duplex">
					<option value="SI" <?php if ($row_terminal["DUPLEX"]=="SI") echo " 'selected'";?>>SI</option>
					<option value="NO" <?php if ($row_terminal["DUPLEX"]=="NO") echo " 'selected'";?>>NO</option>
				</select>
		</TR>
		<TR class="filapar">
			
	<?php
		switch ($row_terminal["ESTADO"]){
			case "A":{
				$estado = "Alta";
				$fecha_nom = "Fecha de Alta";
				$fecha_val = $row_terminal["FALTA"];
				break;
			}
			case "B":{
				$estado = "Alta";
				$fecha_nom = "Fecha de Baja";
				$fecha_val = $row_terminal["FBAJA"];
				break;
			}
			case "R":{
				// Se busca la incidencia
				$sql_incid = "SELECT * FROM incidencias WHERE TERMINAL = '$id' ORDER BY ID DESC";
				$res_incid = mysql_db_query($base_datos,$sql_incid) or die ("Error en la consulta de Incidencia: ".mysql_error());
				$nincid=mysql_num_rows($res_incid);
				if($nflota==0){
					$estado = "<p class='error'>No hay resultados en la consulta de Incidencias</p>\n";
				}
				else{
					$row_incid = mysql_fetch_array($res_incid);
					$id_incid = $row_incid["ID"];
					$estado = "Reparacion - <a href='detalle_incidencia.php?id=$id_incid'><img src='imagenes/consulta.png'></a>";
					$fecha_val = $row_incid["FAVERIA"];
				}
				$fecha_nom = "Fecha de Incidencia";
				break;
			}
		}
	?>
		<TR>
			<TH class="t4c">Estado</TH>
			<TD><?php echo $estado;?></TD>
			<TH class="t4c"><?php echo $fecha_nom;?></TH>
			<TD><?php echo $fecha_val;?></TD>
		</TR>
		<TR class="filapar">
		

	<?php
		if($permiso==2){
	?>
			<TH class="t4c">Nº K</TH>
			<TD><input type="text" name="numerok" size="20" value="<?php echo $row_terminal["NUMEROK"];?>"></TD>
			<TH class="t4c">Carpeta</TH>
			<TD><input type="text" name="carpeta" size="20" value="<?php echo $row_terminal["CARPETA"];?>"></TD>
			</TR>
			<TR>
				<TH class="t4c">Observaciones</TH>
				<TD colspan='3'>
				<input type="text" name="observaciones" size="40" value="<?php echo utf8_encode($row_terminal["OBSERVACIONES"]);?>"></TD>
			</TR>
	<?php
		}
		else{
	?>
				<TH class="t4c">Carpeta</TH>
				<TD><input type="text" name="carpeta" size="20" value="<?php echo $row_terminal["CARPETA"];?>"></TD>
				<TH class="t4c">Observaciones</TH>
				<TD>
				<input type="text" name="observaciones" size="40" value="<?php echo utf8_encode($row_terminal["OBSERVACIONES"]);?>"></TD>
	<?php
		}
	?>
		</TR>
	</table>
	<input type="hidden" name="idterm" value="<?php echo $id;?>">
	<input type="hidden" name="origen" value="editar">
<?php
	if($permiso==2){
?>
	<table>
		<tr>
			<TD class="borde">
				<input type='image' name='action' src='imagenes/guardar.png' alt='Guardar' title="Guardar">
				<br>Guardar Cambios
			</TD>
			<TD class="borde">
				<a href='detalle_terminal.php?id=<?php echo $id;?>'>
					<img src='imagenes/atras.png' alt='Volver' title="Volver">
				</a><br>Volver a detalle
			</TD>
			<TD class="borde">
				<a href='#' onclick='document.formterminal.reset();'>
					<img src='imagenes/no.png' alt='Borrar' title="Borrar">
				</a><br>Cancelar Cambios
			</TD>
		</tr>
	</table>
<?php
	}
?>
</form>
<?php
	}
	else{
?>
	<h1>Acceso denegado</h1>
	<p class='error'>No le está permitido el acceso a los datos de este terminal, pues pertenece a otra flota.</p>
<?php
	}
?>
</body>
</html>
