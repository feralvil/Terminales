<?php
// ------------ Obtención del usuario Joomla! --------------------------------------- //
        // Le decimos que estamos en Joomla
        define( '_JEXEC', 1 );

	// Definimos la constante de directorio actual y el separador de directorios (windows server: \ y linux server: /)
	define( 'DS', DIRECTORY_SEPARATOR );
	define('JPATH_BASE', dirname(__FILE__).DS.'..' );

	// Cargamos los ficheros de framework de Joomla 1.5, y las definiciones de constantes (IMPORTANTE AMBAS LÍNEAS)
	require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

	// Iniciamos nuestra aplicación (site: frontend)
	$mainframe =& JFactory::getApplication('site');

	// Obtenemos los parámetros de Joomla
	$user =& JFactory::getUser();
	$usu = $user->username;
// ------------------------------------------------------------------------------------- //

// ------------ Conexión a BBDD de Terminales ----------------------------------------- //
        include("conexion.php");
        $base_datos=$dbbdatos;
        $link=mysql_connect($dbserv,$dbusu,$dbpaso);
        if(!link){
            echo "<b>ERROR MySQL:</b>".mysql_error();
        }
// ------------------------------------------------------------------------------------- //

import_request_variables("gp","");

/* Determinamos si es usuario OFICINA COMDES para ver la gestión de flotas */
$sql_oficina="SELECT ID FROM flotas WHERE LOGIN='$usu'";
$res_oficina=mysql_db_query($base_datos,$sql_oficina);
$row_oficina=mysql_fetch_array($res_oficina);
$flota_usu=$row_oficina["ID"];
/*
 *  $permiso = variable de permisos de flota:
 *      0: Sin permiso
 *      1: Permiso de consulta
 *      2: Permiso de modificación
 */
$permiso=0;
if($flota_usu==100){
    $permiso = 2;
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Alta del Terminal COMDES</title>
 <link rel="StyleSheet" type="text/css" href="estilo.css">
</head>
<?php
    if($permiso==2){
	//datos de la tabla terminales
	$sql_terminal="SELECT * FROM terminales WHERE ID='$id'";
	$res_terminal=mysql_db_query($base_datos,$sql_terminal) or die ("Error en la consulta de terminal: ".mysql_error());
	$nterminal=mysql_num_rows($res_terminal);
	if($nterminal==0){
		echo "<p class='error'>No hay resultados en la consulta del Terminal</p>\n";
	}
	else{
		$row_terminal=mysql_fetch_array($res_terminal);
		$id_flota = $row_terminal["FLOTA"];
	}
	//datos de la tabla flotas
	$sql_flota="SELECT * FROM flotas WHERE ID='$id_flota'";
	$res_flota=mysql_db_query($base_datos,$sql_flota) or die ("Error en la consulta de terminal: ".mysql_error());
	$nflota=mysql_num_rows($res_terminal);
	if($nflota==0){
		echo "<p class='error'>No hay resultados en la consulta de la Flota</p>\n";
	}
	else{
		$row_flota=mysql_fetch_array($res_flota);
	}
?>
<body>
<h1>Alta del Terminal TEI: <?php echo $row_terminal["TEI"];?> / ISSI: <?php echo $row_terminal["ISSI"];?> de la Flota <?php echo utf8_encode($row_flota["FLOTA"]);?> (<?php echo $row_flota["ACRONIMO"];?>)</h1>
<form action="update_terminal.php" method="POST" name="formterminal">
<?php
		if($row_terminal["ESTADO"]=='A'){
	
?>
<h2>Terminal de alta</h2>
	<div id="resultado">
		<p><img src='imagenes/error.png' alt='Error'></p>
		<p><span class="error"><b>Error:</b> El terminal seleccionado ya está dado de alta</span></p>
		<p><a href="detalle_terminal.php?id=<?php echo $id?>"><img src='imagenes/back.png' alt='Error'></a><BR>Volver</p>
	</div>
<?php
		}
		else{
			$row_flota=mysql_fetch_array($res_flota);
?>
<h2>Confirmar alta</h2>
	<input type="hidden" name="idterm" value="<?php echo $id;?>">
	<input type="hidden" name="origen" value="alta">
	<div class="centro">
		<p><img src='imagenes/important.png' alt='Error'></p>
		<p><span class="error"><b>Atención:</b> Se dispone a dar de alta el terminal seleccionado</span></p>
		<table>
			<TR>
				<TD class="borde">
					<input type='image' name='action' src='imagenes/ok.png' alt='Aceptar' title='Aceptar'><br>Aceptar
				</TD>
				<TD class="borde">
					<a href='detalle_terminal.php?id=<?php echo $id?>'>
						<img src='imagenes/no.png' alt='Cancelar' title='Cancelar'>
					</a><br>Cancelar
				</TD>
			</TR>
		</table>
	</div>
	
<?php
		}
?>
</form>
<?php
	}
	else{
?>
	<h1>Acceso denegado</h1>
	<p class='error'>No le está permitido el acceso a los datos de este terminal, pues pertenece a otra flota.</p>
<?php
	}
?>
</body>
</html>
