<?php
// ------------ Obtención del usuario Joomla! --------------------------------------- //
        // Le decimos que estamos en Joomla
        define( '_JEXEC', 1 );

	// Definimos la constante de directorio actual y el separador de directorios (windows server: \ y linux server: /)
	define( 'DS', DIRECTORY_SEPARATOR );
	define('JPATH_BASE', dirname(__FILE__).DS.'..' );

	// Cargamos los ficheros de framework de Joomla 1.5, y las definiciones de constantes (IMPORTANTE AMBAS LÍNEAS)
	require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

	// Iniciamos nuestra aplicación (site: frontend)
	$mainframe =& JFactory::getApplication('site');

	// Obtenemos los parámetros de Joomla
	$user =& JFactory::getUser();
	$usu = $user->username;
// ------------------------------------------------------------------------------------- //

// ------------ Conexión a BBDD de Terminales ----------------------------------------- //
        include("conexion.php");
        $base_datos=$dbbdatos;
        $link=mysql_connect($dbserv,$dbusu,$dbpaso);
        if(!link){
            echo "<b>ERROR MySQL:</b>".mysql_error();
        }
// ------------------------------------------------------------------------------------- //

import_request_variables("gp","");

/* Determinamos si es usuario OFICINA COMDES para ver la gestión de flotas */
$sql_oficina="SELECT ID FROM flotas WHERE LOGIN='$usu'";
$res_oficina=mysql_db_query($base_datos,$sql_oficina);
$row_oficina=mysql_fetch_array($res_oficina);
$flota_usu=$row_oficina["ID"];
/*
 *  $permiso = variable de permisos de flota:
 *      0: Sin permiso
 *      1: Permiso de consulta
 *      2: Permiso de modificación
 */
$permiso=0;
if($flota_usu==100){
    $permiso = 2;
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Editar Contactos de la Flota COMDES</title>
 <link rel="StyleSheet" type="text/css" href="estilo.css">
</head>
<body>
<?php
	if ($permiso==2){
		if (($detalle=="Responsable")||($detalle=="Contacto 1")||($detalle=="Contacto 2")||($detalle=="Contacto 3")){
			if ($detalle=="Responsable"){
				$id_contacto = $id_resp;
				$nombre = "id_resp";
			}
			if ($detalle=="Contacto 1"){
				$id_contacto = $id_cont1;
				$nombre = "id_cont1";
			}
			if ($detalle=="Contacto 2"){
				$id_contacto = $id_cont2;
				$nombre = "id_cont2";
			}
			if ($detalle=="Contacto 3"){
				$id_contacto = $id_cont3;
				$nombre = "id_cont3";
			}
			$linkpdf = "pdfcontacto.php?id_contacto=$id_contacto&flota=$flota&acronimo=$acronimo&detalle=$detalle";
			$linkxls = "xlscontacto.php?id_contacto=$id_contacto&flota=$flota&acronimo=$acronimo&detalle=$detalle";
			$linkrtf = "rtfcontacto.php?id_contacto=$id_contacto&flota=$flota&acronimo=$acronimo&detalle=$detalle";
?>
<h1>
	Detalle del <?php echo $detalle;?> de la Flota <?php echo $flota;?> (<?php echo $acronimo;?>) &mdash;
	<a href="<?php echo $linkpdf;?>"><img src="imagenes/pdf.png" alt="PDF" title="PDF"></a> &mdash;
	<a href="<?php echo $linkxls;?>"><img src="imagenes/xls.png" alt="Excel" title="XLS (Excel)"></a> &mdash;
	<a href="<?php echo $linkrtf;?>"><img src="imagenes/rtf.png" alt="RTF (Word)" title="RTF (Word)"></a>
</h1>
<?php
	// Datos de contactos
			$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
			$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
			$ncontacto=mysql_num_rows($res_contacto);
			if($ncontacto!=0){
				$row_contacto=mysql_fetch_array($res_contacto);
?>
	<table>
		<TR>
			<TH class="t5c">Nombre</TH>
			<TD class="t40p"><?php echo utf8_encode($row_contacto["NOMBRE"]);?></TD>
			<TH class="t5c">NIF/CIF</TH>
			<TD class="t5c"><?php echo $row_contacto["NIF"];?></TD>
		</TR>
		<TR class="filapar">
			<TH class="t5c">Cargo</TH>
			<TD class="t40p"><?php echo utf8_encode($row_contacto["CARGO"]);?></TD>
			<TH class="t5c">ID</TH>
			<TD class="t5c"><?php echo $row_contacto["ID"];?></TD>
		</TR>
		<TR>
			<TH class="t5c">Teléfono</TH>
			<TD class="t40p"><?php echo $row_contacto["TELEFONO"];?></TD>
			<TH class="t5c">Teléfono GVA</TH>
			<TD class="t5c"><?php echo $row_contacto["TLFGVA"];?></TD>
		</TR>
		<TR class="filapar">
			<TH class="t5c">Móvil</TH>
			<TD class="t40p"><?php echo $row_contacto["MOVIL"];?></TD>
			<TH class="t5c">Móvil GVA</TH>
			<TD class="t5c"><?php echo $row_contacto["MOVILGVA"];?></TD>
		</TR>
		<TR>
			<TH class="t5c">Mail</TH>
			<TD class="t40p"><?php echo utf8_encode($row_contacto["MAIL"]);?></TD>
			<TH class="t5c">Fax</TH>
			<TD class="t5c"><?php echo $row_contacto["FAX"];?></TD>
		</TR>
	</table>
	<form name="detalle_cont" action="editar_contacto.php" method="POST">
		<input type="hidden" name="<?php echo $nombre;?>" value="<?php echo $id_contacto;?>">
		<input type="hidden" name="flota" value="<?php echo $flota;?>">
		<input type="hidden" name="acronimo" value="<?php echo $acronimo;?>">
		<input type="hidden" name="idflota" value="<?php echo $idflota;?>">
		<input type="hidden" name="editar" value="">
		<input type="hidden" name="borrar" value="">
	<table>
		<TR>
			<TD class="borde">
				<input type='image' name='imgedit' value="<?php echo $detalle;?>" src='imagenes/pencil.png' alt='Modificar' onclick="this.form.editar.value=this.value"><br>Editar
			</TD>
			<TD class="borde">
				<input type='image' name='imgdel' value="<?php echo $detalle;?>" src='imagenes/no.png' alt='Borrar' onclick="this.form.borrar.value=this.value"><br>Borrar
			</TD>
			<TD class="borde">
				<a href='contacto_flota.php?id=<?php echo $idflota?>'><img src='imagenes/atras.png' alt='Editar'></a><br>Volver
			</TD>	
		</TR>
	</table>
	</form>
	
<?php
			}
		}
		if (($editar=="Responsable")||($editar=="Contacto 1")||($editar=="Contacto 2")||($editar=="Contacto 3")){
			if ($editar=="Responsable"){
				$id_contacto = $id_resp;
				$nombre = "id_resp";
			}
			if ($editar=="Contacto 1"){
				$id_contacto = $id_cont1;
				$nombre = "id_cont1";
			}
			if ($editar=="Contacto 2"){
				$id_contacto = $id_cont2;
				$nombre = "id_cont2";
			}
			if ($editar=="Contacto 3"){
				$id_contacto = $id_cont3;
				$nombre = "id_cont3";
			}
?>
<h1>Modificar el <?php echo $editar;?> de la Flota <?php echo $flota;?> (<?php echo $acronimo;?>)</h1>
<?php
	// Datos de contactos
			$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
			$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
			$ncontacto=mysql_num_rows($res_contacto);
			if($ncontacto!=0){
				$row_contacto=mysql_fetch_array($res_contacto);
?>
	<form name="editarcont" action="update_contacto.php" method="POST">
		<input type="hidden" name="<?php echo $nombre;?>" value="<?php echo $id_contacto;?>">
		<input type="hidden" name="flota" value="<?php echo $flota;?>">
		<input type="hidden" name="acronimo" value="<?php echo $acronimo;?>">
		<input type="hidden" name="idflota" value="<?php echo $idflota;?>">
                <input type='hidden' name='editar' value="<?php echo $editar;?>">
	<table>
		<TR>
			<TH class="t5c">Nombre</TH>
			<TD class="t40p"><input name="nombre" type="text" value="<?php echo utf8_encode($row_contacto["NOMBRE"]);?>" size="50"></TD>
			<TH class="t5c">NIF</TH>
			<TD class="t5c"><input name="nif" type="text" value="<?php echo $row_contacto["NIF"];?>" size="10"></TD>
		</TR>
		<TR class="filapar">
			<TH class="t5c">Cargo</TH>
			<TD class="t40p"><input name="cargo" type="text" value="<?php echo utf8_encode($row_contacto["CARGO"]);?>" size="50"></TD>
			<TH class="t5c">ID</TH>
			<TD class="t5c"><?php echo $row_contacto["ID"];?></TD>
		</TR>
		<TR>
			<TH class="t5c">Teléfono</TH>
			<TD class="t40p"><input name="telefono" type="text" value="<?php echo $row_contacto["TELEFONO"];?>" size="10"></TD>
			<TH class="t5c">Teléfono GVA</TH>
			<TD class="t5c"><input name="tlf_gva" type="text" value="<?php echo $row_contacto["TLFGVA"];?>" size="10"></TD>
		</TR>
		<TR class="filapar">
			<TH class="t5c">Móvil</TH>
			<TD class="t40p"><input name="movil" type="text" value="<?php echo $row_contacto["MOVIL"];?>" size="10"></TD>
			<TH class="t5c">Móvil GVA</TH>
			<TD class="t40p"><input name="movilgva" type="text" value="<?php echo $row_contacto["MOVILGVA"];?>" size="10"></TD>
		</TR>
		<TR>
			<TH class="t5c">Mail</TH>
			<TD><input name="mail" type="text" value="<?php echo $row_contacto["MAIL"];?>" size="50"></TD>
			<TH class="t5c">Fax</TH>
			<TD class="t5c"><input name="fax" type="text" value="<?php echo $row_contacto["FAX"];?>" size="10"></TD>
		</TR>
	</table>
	<table>
		<TR>
			<TD class="borde">
				<input type='image' name='editimg' value="<?php echo $editar;?>" src='imagenes/guardar.png' alt='Guardar'><br>Guardar
			</TD>
			<TD class="borde">
				<a href='#' onclick='document.editarcont.reset();'><img src='imagenes/no.png' alt='Borrar'></a><br>Cancelar
			</TD>
			<TD class="borde">
				<a href='contacto_flota.php?id=<?php echo $idflota?>'><img src='imagenes/atras.png' alt='Editar'></a><br>Volver
			</TD>
		</TR>
	</table>
	</form>
	
<?php
			}
		}
		if (($nuevo=="Responsable")||($nuevo=="Contacto 1")||($nuevo=="Contacto 2")||($nuevo=="Contacto 3")){
?>
<h1>Nuevo <?php echo $nuevo;?> de la Flota <?php echo $flota;?> (<?php echo $acronimo;?>)</h1>
	<form name="nuevocont" action="update_contacto.php" method="POST">
		<input type="hidden" name="flota" value="<?php echo $flota;?>">
		<input type="hidden" name="acronimo" value="<?php echo $acronimo;?>">
		<input type="hidden" name="idflota" value="<?php echo $idflota;?>">
                <input type="hidden" name='nuevo' value="">
                <input type="hidden" name='nuevoexist' value="">
                <?php
			$sql_contactos = "SELECT * FROM contactos ORDER BY NOMBRE ASC";
			$res_contactos=mysql_db_query($base_datos,$sql_contactos) or die(mysql_error());
			$ncontactos = mysql_num_rows($res_contactos);
                        if ($ncontactos > 0){
                ?>
                <h3>Agregar un contacto existente</h3>
                    <table>
                        <TR>
                            <TD class="borde">
				<select name="contactoexist">
                <?php
                                    for($j=0; $j < $ncontactos; $j++){
                                            $row_contacto = mysql_fetch_array($res_contactos);
                                            $idc = $row_contacto["ID"];
                                            $nombrec = utf8_encode($row_contacto["NOMBRE"]);
?>
                                            <option value="<?php echo $idc;?>"><?php echo $nombrec;?></option>
<?php
                                    }
?>
                                  </select><br><input type='image' name='imgexist' value="<?php echo $nuevo;?>" src='imagenes/adelante.png' alt='Seleccionar' onclick="this.form.nuevoexist.value=this.value">
                            </TD>
                        </TR>
                    </table>
<?php
                        }
?>
<h3>Agregar un nuevo contacto</h3>
	<table>
		<TR>
			<TH class="t5c">Nombre</TH>
			<TD class="t40p"><input name="nombre" type="text" value="" size="50"></TD>
			<TH class="t5c">NIF</TH>
			<TD class="t5c"><input name="nif" type="text" value="" size="10"></TD>
		</TR>
		<TR class="filapar">
			<TH class="t5c">Cargo</TH>
			<TD class="t40p"><input name="cargo" type="text" value="" size="50"></TD>
			<TH class="t5c">ID</TH>
			<TD class="t5c">&nbsp;</TD>
		</TR>
		<TR>
			<TH class="t5c">Teléfono</TH>
			<TD class="t40p"><input name="telefono" type="text" value="" size="10"></TD>
			<TH class="t5c">Teléfono GVA</TH>
			<TD class="t5c"><input name="tlf_gva" type="text" value="" size="10"></TD>
		</TR>
		<TR class="filapar">
			<TH class="t5c">Móvil</TH>
			<TD class="t40p"><input name="movil" type="text" value="" size="10"></TD>
			<TH class="t5c">Móvil GVA</TH>
			<TD class="t5c"><input name="movilgva" type="text" value="" size="10"></TD>
		</TR>
		<TR>
			<TH class="t5c">Mail</TH>
			<TD class="t40p"><input name="mail" type="text" value="" size="50"></TD>
			<TH class="t5c">Fax</TH>
			<TD class="t5c"><input name="fax" type="text" value="" size="10"></TD>
		</TR>
	</table>
	<table>
		<TR>
			<TD class="borde">
				<input type='image' name='imgnew' value="<?php echo $nuevo;?>" src='imagenes/guardar.png' alt='Guardar' onclick="this.form.nuevo.value=this.value"><br>Guardar
			</TD>
			<TD class="borde">
				<a href='#' onclick='document.nuevocont.reset();'><img src='imagenes/no.png' alt='Borrar'></a><br>Borrar
			</TD>
			<TD class="borde">
				<a href='contacto_flota.php?id=<?php echo $idflota?>'><img src='imagenes/atras.png' alt='Volver'></a><br>Volver
			</TD>	
		</TR>
	</table>
	</form>
	
<?php
		}
		if (($borrar=="Responsable")||($borrar=="Contacto 1")||($borrar=="Contacto 2")||($borrar=="Contacto 3")){
			if ($borrar=="Responsable"){
				$id_contacto = $id_resp;
				$nombre = "id_resp";
			}
			if ($borrar=="Contacto 1"){
				$id_contacto = $id_cont1;
				$nombre = "id_cont1";
			}
			if ($borrar=="Contacto 2"){
				$id_contacto = $id_cont2;
				$nombre = "id_cont2";
			}
			if ($borrar=="Contacto 3"){
				$id_contacto = $id_cont3;
				$nombre = "id_cont3";
			}
?>
<h1>Borrar <?php echo $borrar;?> de la Flota <?php echo $flota;?> (<?php echo $acronimo;?>)</h1>
	<form name="bajacont" action="update_contacto.php" method="POST">
	<div class="centro">
		<h2>Confirmar borrado</h2>
		<input type="hidden" name="<?php echo $nombre;?>" value="<?php echo $id_contacto;?>">
		<input type="hidden" name="flota" value="<?php echo $flota;?>">
		<input type="hidden" name="acronimo" value="<?php echo $acronimo;?>">
		<input type="hidden" name="idflota" value="<?php echo $idflota;?>">
                <input type="hidden" name='borrar' value="<?php echo $borrar;?>">
		<p><img src='imagenes/important.png' alt='Atencion'></p>
		<p><span class="error"><b>Atención:</b> Se dispone a borrar el contacto seleccionado de la Flota (Nota: el contacto no será borrado de la base de datos)</span></p>
		<table>
			<tr>
				<TD class="borde">
					<input type='image' name='imgdel' value="<?php echo $borrar;?>" src='imagenes/ok.png' alt='Borrar' title="Borrar"><br>Borrar
				</TD>
				<TD class="borde">
					<a href='contacto_flota.php?id=<?php echo $idflota?>'><img src='imagenes/no.png' alt='Cancelar' title="Cancelar"></a><br>Cancelar
				</TD>
			</tr>
		</table>
	</div>
	</form>
<?php
		}
	}
	else{
?>
	<h1>Acceso denegado</h1>
	<p class='error'>No le está permitido el acceso a los datos de esta flota, pues no es la suya.</p>
<?php
	}
?>
</body>
</html>