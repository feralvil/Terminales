<?php
// ------------ Obtención del usuario Joomla! --------------------------------------- //
        // Le decimos que estamos en Joomla
        define( '_JEXEC', 1 );

	// Definimos la constante de directorio actual y el separador de directorios (windows server: \ y linux server: /)
	define( 'DS', DIRECTORY_SEPARATOR );
	define('JPATH_BASE', dirname(__FILE__).DS.'..' );

	// Cargamos los ficheros de framework de Joomla 1.5, y las definiciones de constantes (IMPORTANTE AMBAS LÍNEAS)
	require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
	require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

	// Iniciamos nuestra aplicación (site: frontend)
	$mainframe =& JFactory::getApplication('site');

	// Obtenemos los parámetros de Joomla
	$user =& JFactory::getUser();
	$usu = $user->username;
// ------------------------------------------------------------------------------------- //

// ------------ Conexión a BBDD de Terminales ----------------------------------------- //
        include("conexion.php");
        $base_datos=$dbbdatos;
        $link=mysql_connect($dbserv,$dbusu,$dbpaso);
        if(!link){
            echo "<b>ERROR MySQL:</b>".mysql_error();
        }
// ------------------------------------------------------------------------------------- //

import_request_variables("gp","");

/* Determinamos si es usuario OFICINA COMDES para ver la gestión de flotas */
$sql_oficina="SELECT ID FROM flotas WHERE LOGIN='$usu'";
$res_oficina=mysql_db_query($base_datos,$sql_oficina);
$row_oficina=mysql_fetch_array($res_oficina);
$flota_usu=$row_oficina["ID"];
if ($id==""){
    $id = $flota_usu;
}
/*
 *  $permiso = variable de permisos de flota:
 *      0: Sin permiso
 *      1: Permiso de consulta
 *      2: Permiso de modificación
 */
$permiso=0;
if($flota_usu==100){
    $permiso = 2;
}
else {
    $sql_permiso = "SELECT * FROM usuarios_flotas WHERE NOMBRE='$usu'";
    $res_permiso = mysql_db_query($base_datos,$sql_permiso) or die(mysql_error());
    $npermiso = mysql_num_rows($res_permiso);
    if ($npermiso == 0){
        $permiso = 0;
    }
    elseif ($npermiso == 1) {
        $row_permiso = mysql_fetch_array($res_permiso);
        if ($id==$row_permiso["FLOTA_ID"]){
            $permiso = 1;
        }
    }
    else {
        for ($i=0; $i < $npermiso; $i++){
            $row_permiso = mysql_fetch_array($res_permiso);
            if ($id==$row_permiso["ID_FLOTA"]){
                $permiso++;
            }
        }
    }
}

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Detalle de Flota COMDES</title>
 <link rel="StyleSheet" type="text/css" href="estilo.css">
</head>
<body>
<?php
	if ($permiso!=0){
		//datos de la tabla Flotas
		$sql_flota="SELECT * FROM flotas WHERE ID='$id'";
		$res_flota=mysql_db_query($base_datos,$sql_flota) or die ("Error en la consulta de Flota: ".mysql_error());
		$nflota=mysql_num_rows($res_flota);
		if($nflota==0){
			echo "<p class='error'>No hay resultados en la consulta de la Flota</p>\n";
		}
		else{
			$row_flota=mysql_fetch_array($res_flota);
                        $usuario = $row_flota["LOGIN"];
		}
		//datos de la tabla Terminales
		// Tipos de termninales
		$tipos = array("F","M%","MB","MA", "MG", "P%", "PB", "PA", "PX");
		$cabecera = array("Terminales Fijos","Terminales Móviles","Móviles Básicos","Móviles Avanzados", "Móviles Gateway", "Terminales Portátiles", "Portátiles Básicos", "Portátiles Avanzados", "Portátiles ATEX");
		$nterm = array (0,0,0,0,0,0,0,0,0);
		$sql_term = "SELECT * FROM terminales WHERE FLOTA='$id'";
		$res_term = mysql_db_query($base_datos,$sql_term) or die ("Error en la consulta de Terminales".mysql_error());
		$tot_term = mysql_num_rows($res_term);
		for($j=0; $j< count($tipos);$j++){
			$sql_term = "SELECT * FROM terminales WHERE FLOTA='$id' AND TIPO LIKE '".$tipos[$j]."'";
			$res_term = mysql_db_query($base_datos,$sql_term) or die ("Error en la consulta de ".$cabecera[$j].": ".mysql_error());
			$nterm[$j] = mysql_num_rows($res_term);
		}
		//datos de la tabla Municipio
		// INE
		$ine =$row_flota["INE"];
		$sql_mun = "SELECT * FROM municipios WHERE INE='$ine'";
		$res_mun = mysql_db_query($base_datos,$sql_mun) or die ("Error en la consulta de Municipio".mysql_error());
		$nmun = mysql_num_rows($res_mun);
		if($nmun==0){
			echo "<p class='error'>No hay resultados en la consulta del Municipio</p>\n";
		}
		else{
			$row_mun = mysql_fetch_array($res_mun);
		}
	
		############# Enlaces para la exportación #######
		$linkpdf = "pdfflota.php?id=$id";
		$linkxls = "xlsflota.php?id=$id";
		$linkrtf = "rtfflota.php?id=$id";
?>
<h1>
	Flota <?php echo utf8_encode($row_flota["FLOTA"]);?> (<?php echo $row_flota["ACRONIMO"];?>) &mdash;
			<a href="<?php echo $linkpdf;?>"><img src="imagenes/pdf.png" alt="PDF" title="PDF"></a> &mdash;
			<a href="<?php echo $linkxls;?>"><img src="imagenes/xls.png" alt="Excel" title="XLS (Excel)"></a> &mdash;
			<a href="<?php echo $linkrtf;?>"><img src="imagenes/rtf.png" alt="RTF (Word)" title="RTF (Word)"></a>
</h1>

<h2>Datos Administrativos de la Flota</h2>
	<table>
		<TR>
			<TH class="t40p">Nombre</TH>
			<TH class="t5c">Acrónimo</TH>
			<TH class="t5c">Usuario</TH>
			<TH class="t10c">Activa</TH>
			<TH class="t10c">Encriptación</TH>
		</TR>
		<TR>
			<TD><?php echo utf8_encode($row_flota["FLOTA"]);?></TD>
			<TD><?php echo $row_flota["ACRONIMO"];?></TD>
			<TD><?php echo $row_flota["LOGIN"];?></TD>
			<TD><?php echo $row_flota["ACTIVO"];?></TD>
                        <TD><?php echo $row_flota["ENCRIPTACION"];?></TD>
		</TR>
	</table>
<h2>Datos de Localización de la Flota</h2>
	<table>
		<TR>
			<TH class="t40p">Domicilio</TH>
			<TH class="t10c">C.P.</TH>
			<TH class="t30">Ciudad</TH>
			<TH class="t5c">Provincia</TH>
		</TR>
		<TR>
			<TD><?php echo utf8_encode($row_flota["DOMICILIO"]);?></TD>
			<TD><?php echo $row_flota["CP"];?></TD>
			<TD><?php echo utf8_encode($row_mun["MUNICIPIO"]);?></TD>
			<TD><?php echo utf8_encode($row_mun["PROVINCIA"]);?></TD>
		</TR>
	</table>
<h2>Contactos de la Flota</h2>
<?php
	if (($row_flota["RESPONSABLE"]=="0")&&($row_flota["CONTACTO1"]=="0")&&($row_flota["CONTACTO2"]=="0")&&($row_flota["CONTACTO3"]=="0")){
?>
		<p class='error'>No hay Contactos para la flota</p>
<?php
	}
	else{
?>
	<table>
		<TR>
			<TD class="t10c">&nbsp;</TD>
			<TH class="t4c">Nombre</TH>
			<TH class="t4c">Cargo</TH>
			<TH class="t10c">Teléfono</TH>
			<TH class="t10c">Móvil</TH>
			<TH class="t5c">Correo Electrónico</TH>
		</TR>

<?php
		$par = 0;
		// Datos de contactos
		$id_contacto = $row_flota["RESPONSABLE"];
		$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
		$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
		$ncontacto=mysql_num_rows($res_contacto);
		if($ncontacto!=0){
			$row_contacto=mysql_fetch_array($res_contacto);
?>
		<TR>
			<TH>Responsable</TH>
			<TD><?php echo utf8_encode($row_contacto["NOMBRE"]);?></TD>
			<TD><?php echo utf8_encode($row_contacto["CARGO"]);?></TD>
			<TD><?php echo utf8_encode($row_contacto["TELEFONO"]);?></TD>
			<TD><?php echo utf8_encode($row_contacto["MOVIL"]);?></TD>
			<TD><?php echo utf8_encode($row_contacto["MAIL"]);?></TD>
		</TR>
	<?php
			$par++;
		
		}
		if ($row_flota["CONTACTO1"]!="0"){
			$id_contacto = $row_flota["CONTACTO1"];
			$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
			$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
			$ncontacto=mysql_num_rows($res_contacto);
			if($ncontacto==0){
				echo "<p class='error'>No hay resultados en la consulta del Contacto 1</p>\n";
			}
			else{
				$row_contacto=mysql_fetch_array($res_contacto);
			}
	?>
			<TR <?php if (($par % 2)==1) echo "class='filapar'";?>>
				<TH>Contacto 1</TH>
				<TD><?php echo utf8_encode($row_contacto["NOMBRE"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["CARGO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["TELEFONO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MOVIL"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MAIL"]);?></TD>
			</TR>
	<?php
			$par++;
		}
		if ($row_flota["CONTACTO2"]!="0"){
			$id_contacto = $row_flota["CONTACTO2"];
			$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
			$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
			$ncontacto=mysql_num_rows($res_contacto);
			if($ncontacto==0){
				echo "<p class='error'>No hay resultados en la consulta del Contacto 2</p>\n";
			}
			else{
				$row_contacto=mysql_fetch_array($res_contacto);
			}
	?>
			<TR <?php if (($par % 2)==1) echo "class='filapar'";?>>
				<TH>Contacto 2</TH>
				<TD><?php echo utf8_encode($row_contacto["NOMBRE"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["CARGO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["TELEFONO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MOVIL"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MAIL"]);?></TD>
			</TR>
	<?php
			$par++;
		}
		if ($row_flota["CONTACTO3"]!="0"){
			$id_contacto = $row_flota["CONTACTO3"];
			$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
			$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
			$ncontacto=mysql_num_rows($res_contacto);
			if($ncontacto==0){
				echo "<p class='error'>No hay resultados en la consulta del Contacto 3</p>\n";
			}
			else{
				$row_contacto=mysql_fetch_array($res_contacto);
			}
	?>
			<TR <?php if (($par % 2)==1) echo "class='filapar'";?>>
				<TH>Contacto 3</TH>
				<TD><?php echo utf8_encode($row_contacto["NOMBRE"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["CARGO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["TELEFONO"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MOVIL"]);?></TD>
				<TD><?php echo utf8_encode($row_contacto["MAIL"]);?></TD>
			</TR>
	<?php
		}
	?>
	</table>
<?php
	}
?>
<h2>Resúmen de Terminales de la Flota</h2>
	<table>
		<TR>
			<TH class="t10c">Total Terminales</TH>
<?php
		for ($i = 0 ; $i < count($tipos); $i++) {
?>
			<TH class="t10c"><?php echo $cabecera[$i];?></TH>
<?php
		}
?>
		</TR>
		<TR>
			<TD class="centro"><?php echo $tot_term;?></TD>
<?php
		for ($i = 0 ; $i < count($tipos); $i++) {
?>
			<TD class="centro"><?php echo $nterm[$i];?></TD>
<?php
		}
?>
		</TR>
	</table>
<?php
    if (($permiso==1)||(($permiso==2)&&($id!=100))){
?>
        <h2>Flotas a las que tiene acceso</h2>
<?php
         $sql_flotas = "SELECT ID, ACRONIMO, FLOTA FROM flotas, usuarios_flotas WHERE ";
         $sql_flotas = $sql_flotas."usuarios_flotas.NOMBRE='$usuario' AND flotas.ID = usuarios_flotas.ID_FLOTA";
         $res_flotas=mysql_db_query($base_datos,$sql_flotas) or die(mysql_error());
         $nflotas=mysql_num_rows($res_flotas);
?>
        <table>
            <tr>
                <th>Detalle</th>
                <th>Acrónimo</th>
                <th>Flota</th>
                <td>&nbsp;</td>
                <th>Detalle</th>
                <th>Acrónimo</th>
                <th>Flota</th>
            </tr>
<?php
            $filas = floor($nflotas / 2);
            if (($nflotas % 2)==1){
                $filas += 1;
            }
            for ($i = 0; $i < $filas; $i++){
?>
                <tr <?php if (($i % 2) == 1) echo "class='filapar'" ?>
<?php
                for ($j = 0; $j < 2; $j++){
                    $row_flotas = mysql_fetch_array($res_flotas);
?>
                    <td class="centro">
<?php
                    if ($row_flotas["ID"]!=""){
?>
                        <a href="detalle_flota.php?id=<?php echo $row_flotas["ID"];?>"><img src='imagenes/consulta.png' alt="Detalle" title="Detalle"></a>
<?php
                    }
?>
                    </td>
                    <td><?php echo $row_flotas["ACRONIMO"];?></td>
                    <td><?php echo utf8_encode($row_flotas["FLOTA"]);?></td>
 <?php
                    if ($j==0){
?>
                        <td>&nbsp</td>
<?php
                    }
                }
?>
                </tr>
<?php
            }
?>
        </table>
<?php
     }
?>
	<table>
		<tr>
<?php
	if ($permiso==2){
?>

			<TD class="borde">
				<a href='editar_flota.php?id=<?php echo $id?>'><img src='imagenes/pencil.png' alt='Editar'></a><br>Editar Flota
			</TD>	
			<TD class="borde">
				<a href='contacto_flota.php?id=<?php echo $id?>'><img src='imagenes/editacont.png' alt='Editar'></a><br>Editar Contactos
			</TD>
                <?php
                    if ($id!=100){
                ?>
			<TD class="borde">
				<a href='permisos_flota.php?id=<?php echo $id?>'><img src='imagenes/password.png' alt='Editar'></a><br>Acceso a Flotas
			</TD>
                <?php
                    }
                ?>
		<?php
			if($row_flota["ACTIVO"]=="SI"){
                                $enlace = "baja_flota.php?id=$id";
				$nombre = "desactivar";
				$imagen = "imagenes/desactiva.png";
				$alt = "Desactivar Flota";
			}
			else {
                                $enlace = "alta_flota.php?id=$id";
				$nombre = "activar";
				$imagen = "imagenes/activa.png";
				$alt = "Activar Flota";
			}
		?>
			<td class='borde'>
                            <a href='<?php echo $enlace?>'><img src='<?php echo $imagen?>' alt='<?php echo $alt?>' title="<?php echo $alt;?>"></a><br><?php echo $alt;?>
			</td>
                        <TD class="borde">
				<a href='nuevo_terminal.php?id=<?php echo $id?>'><img src='imagenes/nuevo.png' alt='Editar'></a><br>Añadir Terminal a la Flota
			</TD>
<?php
	}
?>
			<TD class="borde">
				<a href='terminales.php?flota=<?php echo $id?>'><img src='imagenes/lista.png' alt='Listado'></a><br>Terminales de la Flota
			</TD>
		</tr>
	</table>
<?php
	}
	else{
?>
	<h1>Acceso denegado</h1>
	<p class='error'>No le está permitido el acceso a los datos de esta flota</p>
<?php
	}
?>
</body>
</html>