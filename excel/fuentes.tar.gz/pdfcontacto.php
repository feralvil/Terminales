<?php
include_once ("auth.php");
include_once ("authconfig.php");
include_once ("check.php");

/* GENERACIÓN DEL PDF */
require_once('tcpdf/config/lang/esp.php');
require_once('tcpdf/tcpdf.php');

include("conexion.php");

$base_datos=$dbbdatos;
$link=mysql_connect($dbserv,$dbusu,$dbpaso);
if(!link){
	echo "<b>ERROR MySQL:</b>".mysql_error();
}
import_request_variables("gp","");

/* Determinamos si es usuario OFICINA COMDES para ver la gestión de flotas */
$usu=$_COOKIE["USUARIO"];
$sql_oficina="SELECT ID FROM flotas WHERE LOGIN='$usu'";
$res_oficina=mysql_db_query($base_datos,$sql_oficina);
$row_oficina=mysql_fetch_array($res_oficina);
$flota_usu=$row_oficina["ID"];

// Extender la clase TCPDF para crear una cabecera y un pie de página propios
class MYPDF extends TCPDF {
	
	//Cabecera
	public function Header() {
		// Logo
		$this->Image('imagenes/comdes2.png',20);
		// Establecemos la fuente y colores
		$this->SetDrawColor(92, 116, 61);
		$this->SetTextColor(92, 116, 61);
		$this->SetFont('helvetica', 'B', 12);
		// Nos desplazamos a a la derecha
		$this->Cell(20);
		// Título
		$this->Cell(140, 10, 'Contacto de la RED COMDES', 0, 0, 'C');
		// Logo 2
		$this->Image('imagenes/logo.jpg');
		// Salto de línea
		$this->Ln();
		$this->Cell(0, 0, '', 'T');
		$this->Ln();
	}
	
	// Pie de página
	public function Footer() {
		// Posición at 1.5 cm del fin de página
		$this->SetY(-15);
		// Establecemos la fuente y colores
		$this->SetDrawColor(92, 116, 61);
		$this->SetTextColor(92, 116, 61);
		$this->SetFont('helvetica', 'B', 8);
		// Número de Página
		$this->Cell(0, 10, 'Página '.$this->getAliasNumPage().' de '.$this->getAliasNbPages(), 'T', 0, 'C');
	}
	
	/*
		Función para simplificar la impresión de tablas. Imprime 1 fila de tabla.
		Argumentos:
			- $fila = Fila a imprimir. Incluye datos y/o cabeceras
			- $anchos = Ancho de cada columna (en mm)
			- $campos = Tipo de celda a imprimir:
				- -1 : Celda en Blanco (Celda vacía sin relleno)
				- 0 : Celda de Cabecera (Negrita, con relleno, centrada)
				- 1: Celda de Datos  (Sin negrita, relleno alterno, alineada a la la izquierda)
			- $par = Indica si es una fila par (con relleno gris)
	*/
	public function ImprimeFila($fila, $anchos, $campos, $par) {
		$filas = 1;
		// Comprobamos los anchos
		for ($i=0; $i < count ($anchos); $i++){
			$filas_celda = $this->GetNumLines ($fila[$i], $anchos[$i]);
			if ($filas_celda > $filas) {
				$filas = $filas_celda;
			}
		}
		for ($i=0; $i < count ($anchos); $i++){
			if ($campos[$i]==-1) {
				//$this->Cell($anchos[$i], 5*$filas, '', 0, 'C', 0);
				$fill = 0;
				$borde = 0;
			}
			elseif ($campos[$i]==0) {
				$this->SetFillColor(92, 116, 61);
				$this->SetTextColor(213, 235, 179);
				$this->SetFont('', 'B',10);
				$fill = 1;
				$borde = 1;
				$alin = 'C';
				//$this->Cell($anchos[$i], 5*$filas, $fila[$i], 1, 0, 'C', 1);
			}
			else {
				$fill = 0;
				if ($par){
					$fill = 1;
				}
				$borde = 1;
				$alin = 'L';
				$this->SetFillColor(194, 194, 194);
				$this->SetTextColor(0, 0, 0);
				$this->SetFont('', '',10);
				/*if ($this->GetStringWidth($fila[$i]) > $anchos[$i]) {
					$this->MultiCell($anchos[$i], 5, $fila[$i], 1, 'L', 0, 0, '', '', true, 0);
				}
				else {
					$this->Cell($anchos[$i], 5*$filas, $fila[$i], 1, 0, 'L', $fill);
				}*/
			}
			if ($filas == 1){
				$this->Cell($anchos[$i], 5, $fila[$i], $borde, 0, $alin, $fill);
			}
			else{
				//$this->MultiCell($anchos[$i], 5, $fila[$i], $borde, 'L', 0, 0, '', '', true, 0);
				$this->MultiCell($anchos[$i], 5*$filas, $fila[$i], $borde, $alin, $fill, 0, '', '', true, 0, false, false);
			}
		}
		$this->Ln();
	}
}

// crear nuevo documento
$pdf = new MYPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Información de documento
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Oficina COMDES');
$pdf->SetTitle('Contacto de la Red COMDES');
$pdf->SetSubject('Contacto de la Red COMDES');
$pdf->SetKeywords('COMDES, Contacto');

// Márgenes
$pdf->SetMargins(15, PDF_MARGIN_TOP, 15);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// Salto automático de página
$pdf->SetAutoPageBreak(TRUE, 15);

// Factor de Escala de las imágenes
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// Cadenas de texto dependientes del Idioma
$pdf->setLanguageArray($l);
// Establecemos la fuente por defecto
$pdf->SetFont('helvetica', '', 8);
// Añadir una página
$pdf->AddPage();

// ---------------------------------------------------------

if($flota_usu==5){
	// Datos del contacto
	$sql_contacto = "SELECT * FROM contactos WHERE ID=$id_contacto";
	$res_contacto=mysql_db_query($base_datos,$sql_contacto) or die ("Error en la consulta de contacto: ".mysql_error());
	$ncontacto=mysql_num_rows($res_contacto);
	if($ncontacto!=0){
		$row_contacto=mysql_fetch_array($res_contacto);
	
		// Colores y Fuente para los títulos
		$pdf->SetFillColor(92, 116, 61);
		$pdf->SetTextColor(92, 116, 61);
		$pdf->SetDrawColor(92, 116, 61);
		$pdf->SetLineWidth(0.3);
		$pdf->SetFont('', 'B',12);
		$titulo = "Detalle del $detalle de la Flota $flota ($acronimo)";
		$pdf->MultiCell(0,5,$titulo,0,'C',0);
		$pdf->Ln(5);
		$fila_imp = array('Nombre', utf8_encode($row_contacto["NOMBRE"]), 'NIF/CIF', $row_contacto["NIF"]);
		$anchos_imp = array(30, 80, 30, 40);
		$campos_imp = array(0,1,0,1);
		$pdf->ImprimeFila ($fila_imp, $anchos_imp, $campos_imp, false);
		$fila_imp = array('Cargo', utf8_encode($row_contacto["CARGO"]), 'ID', $row_contacto["ID"]);
		$pdf->ImprimeFila ($fila_imp, $anchos_imp, $campos_imp, true);
		$fila_imp = array('Domicilio', utf8_encode($row_contacto["DIRECCION"]), 'C.P.', $row_contacto["CP"]);
		$pdf->ImprimeFila ($fila_imp, $anchos_imp, $campos_imp, false);
		$fila_imp = array('Localidad', utf8_encode($row_contacto["LOCALIDAD"]), 'Provincia', utf8_encode($row_contacto["PROVINCIA"]));
		$pdf->ImprimeFila ($fila_imp, $anchos_imp, $campos_imp, true);
		$fila_imp = array('Teléfono', $row_contacto["TELEFONO"], 'Tlf. Corporativo', $row_contacto["TLF_GVA"]);
		$pdf->ImprimeFila ($fila_imp, $anchos_imp, $campos_imp, false);
		$fila_imp = array('Móvil', $row_contacto["MOVIL"], 'Fax', $row_contacto["FAX"]);
		$pdf->ImprimeFila ($fila_imp, $anchos_imp, $campos_imp, true);
		$fila_imp = array('Mail', $row_contacto["MAIL"]);
		$anchos_imp = array(30, 150);
		$campos_imp = array(0,1);
		$pdf->ImprimeFila ($fila_imp, $anchos_imp, $campos_imp, false);
		$pdf->Ln(5);
	}
	else {
		$error = "Error en la consulta del $detalle de la Flota $flota";
		$pdf->SetTextColor(255, 0, 0);
		$pdf->SetFont('', 'B',10);
		$pdf->MultiCell(0,5,$error,0,'L',0);
	}
}
else {
	$error = "Acceso denegado. No le está permitido el acceso a los datos de este contacto, pues pertenece a otra flota.";
	$pdf->SetTextColor(255, 0, 0);
	$pdf->SetFont('', 'B',10);
	$pdf->MultiCell(0,5,$error,0,'L',0);
}

	// Generar y enviar el documento PDF
	$pdf->Output("Contacto_COMDES-$id_contacto.pdf", 'I');
?>
